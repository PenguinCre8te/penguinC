#include "ast.h"

AstNode *ast_create_node(NodeType type, int line, int col) {
    AstNode *node = calloc(1, sizeof(AstNode));
    node->type = type;
    node->line = line;
    node->col = col;
    return node;
}

static void indent(int level) {
    for (int i = 0; i < level; i++) printf("  ");
}

void ast_print(AstNode *node, int indent_level) {
    if (!node) return;
    switch (node->type) {
        case NODE_PROGRAM: {
            AstNode **stmts = node->data.block.stmts;
            int count = node->data.block.stmt_count;
            indent(indent_level); printf("Program(%d stmts)\n", count);
            for (int i = 0; i < count; i++) ast_print(stmts[i], indent_level + 1);
            break;
        }
        case NODE_IMPORT:
            indent(indent_level); printf("Import(%s)\n", node->data.import.name);
            break;
        case NODE_LINK:
            indent(indent_level); printf("Link(%s)\n", node->data.link.path);
            break;
        case NODE_STRUCT_DEF:
            indent(indent_level); printf("Struct(%s, %d fields)\n",
                node->data.struct_def.name, node->data.struct_def.field_count);
            for (int i = 0; i < node->data.struct_def.field_count; i++)
                ast_print(node->data.struct_def.fields[i], indent_level + 1);
            break;
        case NODE_CLASS_DEF:
            indent(indent_level); printf("Class(%s, extends=%s, %d members)\n",
                node->data.class_def.name,
                node->data.class_def.parent ? node->data.class_def.parent : "none",
                node->data.class_def.member_count);
            for (int i = 0; i < node->data.class_def.member_count; i++)
                ast_print(node->data.class_def.members[i], indent_level + 1);
            break;
        case NODE_FUNC_DEF:
            indent(indent_level); printf("Func(%s, %d params)\n",
                node->data.func_def.name, node->data.func_def.param_count);
            for (int i = 0; i < node->data.func_def.param_count; i++)
                ast_print(node->data.func_def.params[i], indent_level + 1);
            ast_print(node->data.func_def.body, indent_level + 1);
            break;
        case NODE_FUNC_PARAM:
            indent(indent_level); printf("Param(%s%s%s)\n",
                node->data.func_param.is_borrow ? "borrow " : "",
                node->data.func_param.is_mut ? "mut " : "",
                node->data.func_param.name);
            break;
        case NODE_BLOCK: {
            indent(indent_level); printf("Block(%d stmts)\n",
                node->data.block.stmt_count);
            for (int i = 0; i < node->data.block.stmt_count; i++)
                ast_print(node->data.block.stmts[i], indent_level + 1);
            break;
        }
        case NODE_RETURN:
            indent(indent_level); printf("Return\n");
            if (node->data.unary.operand)
                ast_print(node->data.unary.operand, indent_level + 1);
            break;
        case NODE_IF:
            indent(indent_level); printf("If\n");
            ast_print(node->data.if_stmt.expr, indent_level + 1);
            ast_print(node->data.if_stmt.then_block, indent_level + 1);
            if (node->data.if_stmt.else_block)
                ast_print(node->data.if_stmt.else_block, indent_level + 1);
            break;
        case NODE_SWITCH:
            indent(indent_level); printf("Switch(%d cases)\n",
                node->data.switch_stmt.case_count);
            ast_print(node->data.switch_stmt.expr, indent_level + 1);
            for (int i = 0; i < node->data.switch_stmt.case_count; i++)
                ast_print(node->data.switch_stmt.cases[i], indent_level + 1);
            break;
        case NODE_CASE:
            indent(indent_level); printf("Case\n");
            if (node->data.case_branch.value)
                ast_print(node->data.case_branch.value, indent_level + 1);
            ast_print(node->data.case_branch.body, indent_level + 1);
            break;
        case NODE_MATCH:
            indent(indent_level); printf("Match(%d cases)\n",
                node->data.match_stmt.case_count);
            ast_print(node->data.match_stmt.expr, indent_level + 1);
            for (int i = 0; i < node->data.match_stmt.case_count; i++)
                ast_print(node->data.match_stmt.cases[i], indent_level + 1);
            break;
        case NODE_MATCH_CASE:
            indent(indent_level); printf("MatchCase\n");
            if (node->data.case_branch.value)
                ast_print(node->data.case_branch.value, indent_level + 1);
            ast_print(node->data.case_branch.body, indent_level + 1);
            break;
        case NODE_FOR:
            indent(indent_level); printf("For(%s)\n", node->data.for_stmt.var);
            ast_print(node->data.for_stmt.range, indent_level + 1);
            ast_print(node->data.for_stmt.body, indent_level + 1);
            break;
        case NODE_USING:
            indent(indent_level); printf("Using\n");
            ast_print(node->data.using_stmt.resource, indent_level + 1);
            ast_print(node->data.using_stmt.body, indent_level + 1);
            break;
        case NODE_UNSAFE:
            indent(indent_level); printf("Unsafe\n");
            ast_print(node->data.unsafe_stmt.body, indent_level + 1);
            break;
        case NODE_BINARY:
            indent(indent_level); printf("Binary(%s)\n", node->data.binary.op_str);
            ast_print(node->data.binary.lhs, indent_level + 1);
            ast_print(node->data.binary.rhs, indent_level + 1);
            break;
        case NODE_UNARY:
            indent(indent_level); printf("Unary(%s)\n", node->data.unary.op);
            ast_print(node->data.unary.operand, indent_level + 1);
            break;
        case NODE_CALL:
            indent(indent_level); printf("Call(%s, %d args)\n",
                node->data.call.name, node->data.call.arg_count);
            for (int i = 0; i < node->data.call.arg_count; i++)
                ast_print(node->data.call.args[i], indent_level + 1);
            break;
        case NODE_MEMBER_ACCESS:
            indent(indent_level); printf("MemberAccess(%s)\n", node->data.member_access.member);
            ast_print(node->data.member_access.object, indent_level + 1);
            break;
        case NODE_NEW:
            indent(indent_level); printf("New(%d args)\n", node->data.new_expr.arg_count);
            for (int i = 0; i < node->data.new_expr.arg_count; i++)
                ast_print(node->data.new_expr.args[i], indent_level + 1);
            break;
        case NODE_IDENTIFIER:
            indent(indent_level); printf("Ident(%s)\n", node->data.identifier);
            break;
        case NODE_INT_LIT:
            indent(indent_level); printf("Int(%ld)\n", node->data.int_value);
            break;
        case NODE_STRING_LIT:
            indent(indent_level); printf("String(\"%s\")\n", node->data.string_value);
            break;
        case NODE_RANGE:
            indent(indent_level); printf("Range\n");
            ast_print(node->data.range.start, indent_level + 1);
            ast_print(node->data.range.end, indent_level + 1);
            break;
        case NODE_STRUCT_INIT:
            indent(indent_level); printf("StructInit(%d args)\n",
                node->data.struct_init.arg_count);
            for (int i = 0; i < node->data.struct_init.arg_count; i++)
                ast_print(node->data.struct_init.args[i], indent_level + 1);
            break;
        default:
            indent(indent_level); printf("Node(%d)\n", node->type);
            break;
    }
}

void ast_free(AstNode *node) {
    if (!node) return;
    switch (node->type) {
        case NODE_PROGRAM:
        case NODE_BLOCK:
            for (int i = 0; i < node->data.block.stmt_count; i++)
                ast_free(node->data.block.stmts[i]);
            free(node->data.block.stmts);
            break;
        case NODE_IMPORT:
            free(node->data.import.name);
            free(node->data.import.alias);
            break;
        case NODE_LINK:
            free(node->data.link.path);
            break;
        case NODE_STRUCT_DEF:
            free(node->data.struct_def.name);
            for (int i = 0; i < node->data.struct_def.field_count; i++)
                ast_free(node->data.struct_def.fields[i]);
            free(node->data.struct_def.fields);
            break;
        case NODE_CLASS_DEF:
            free(node->data.class_def.name);
            free(node->data.class_def.parent);
            for (int i = 0; i < node->data.class_def.member_count; i++)
                ast_free(node->data.class_def.members[i]);
            free(node->data.class_def.members);
            break;
        case NODE_FUNC_DEF:
            free(node->data.func_def.name);
            for (int i = 0; i < node->data.func_def.param_count; i++)
                ast_free(node->data.func_def.params[i]);
            free(node->data.func_def.params);
            ast_free(node->data.func_def.body);
            break;
        case NODE_FUNC_PARAM:
            free(node->data.func_param.name);
            ast_free(node->data.func_param.type);
            break;
        case NODE_IF:
            ast_free(node->data.if_stmt.expr);
            ast_free(node->data.if_stmt.then_block);
            ast_free(node->data.if_stmt.else_block);
            break;
        case NODE_SWITCH:
            ast_free(node->data.switch_stmt.expr);
            for (int i = 0; i < node->data.switch_stmt.case_count; i++)
                ast_free(node->data.switch_stmt.cases[i]);
            free(node->data.switch_stmt.cases);
            break;
        case NODE_CASE:
            ast_free(node->data.case_branch.value);
            ast_free(node->data.case_branch.body);
            break;
        case NODE_MATCH:
            ast_free(node->data.match_stmt.expr);
            for (int i = 0; i < node->data.match_stmt.case_count; i++)
                ast_free(node->data.match_stmt.cases[i]);
            free(node->data.match_stmt.cases);
            break;
        case NODE_MATCH_CASE:
            ast_free(node->data.case_branch.value);
            ast_free(node->data.case_branch.body);
            break;
        case NODE_FOR:
            free(node->data.for_stmt.var);
            ast_free(node->data.for_stmt.range);
            ast_free(node->data.for_stmt.body);
            break;
        case NODE_USING:
            ast_free(node->data.using_stmt.resource);
            ast_free(node->data.using_stmt.body);
            break;
        case NODE_UNSAFE:
            ast_free(node->data.unsafe_stmt.body);
            break;
        case NODE_BINARY:
            free(node->data.binary.op_str);
            ast_free(node->data.binary.lhs);
            ast_free(node->data.binary.rhs);
            break;
        case NODE_UNARY:
            free(node->data.unary.op);
            ast_free(node->data.unary.operand);
            break;
        case NODE_CALL:
            free(node->data.call.name);
            for (int i = 0; i < node->data.call.arg_count; i++)
                ast_free(node->data.call.args[i]);
            free(node->data.call.args);
            break;
        case NODE_MEMBER_ACCESS:
            free(node->data.member_access.member);
            ast_free(node->data.member_access.object);
            break;
        case NODE_NEW:
            for (int i = 0; i < node->data.new_expr.arg_count; i++)
                ast_free(node->data.new_expr.args[i]);
            free(node->data.new_expr.args);
            break;
        case NODE_SIZEOF:
            ast_free(node->data.sizeof_expr.type);
            ast_free(node->data.sizeof_expr.size);
            break;
        case NODE_FREE:
            ast_free(node->data.free_expr.expr);
            break;
        case NODE_DROP:
            ast_free(node->data.drop_expr.expr);
            break;
        case NODE_RANGE:
            ast_free(node->data.range.start);
            ast_free(node->data.range.end);
            break;
        case NODE_STRING_LIT:
            free(node->data.string_value);
            break;
        case NODE_IDENTIFIER:
            free(node->data.identifier);
            break;
        case NODE_STRUCT_INIT:
            for (int i = 0; i < node->data.struct_init.arg_count; i++)
                ast_free(node->data.struct_init.args[i]);
            free(node->data.struct_init.args);
            break;
        case NODE_RETURN:
            ast_free(node->data.unary.operand);
            break;
        case NODE_BORROW_EXPR:
            ast_free(node->data.borrow_expr.expr);
            break;
        case NODE_THREAD_RUN:
            ast_free(node->data.thread_run.call);
            break;
        default:
            break;
    }
    free(node);
}
