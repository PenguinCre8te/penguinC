/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* First part of user prologue.  */
#line 1 "parser.y"

#include "ast.h"
#include <stdio.h>
#include <string.h>

extern int yylex(void);
extern int yylineno;
extern int yycolumn;
extern FILE *yyin;

void yyerror(const char *s);

AstNode *program_root = NULL;

#line 86 "parser.tab.c"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

#include "parser.tab.h"
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_IDENTIFIER = 3,                 /* IDENTIFIER  */
  YYSYMBOL_INT_LIT = 4,                    /* INT_LIT  */
  YYSYMBOL_STRING_LIT = 5,                 /* STRING_LIT  */
  YYSYMBOL_STRING_INTERP = 6,              /* STRING_INTERP  */
  YYSYMBOL_IMPORT = 7,                     /* IMPORT  */
  YYSYMBOL_LINK = 8,                       /* LINK  */
  YYSYMBOL_AS = 9,                         /* AS  */
  YYSYMBOL_STRUCT = 10,                    /* STRUCT  */
  YYSYMBOL_CLASS = 11,                     /* CLASS  */
  YYSYMBOL_EXTENDS = 12,                   /* EXTENDS  */
  YYSYMBOL_VOID = 13,                      /* VOID  */
  YYSYMBOL_INT = 14,                       /* INT  */
  YYSYMBOL_STRING = 15,                    /* STRING  */
  YYSYMBOL_LOCK = 16,                      /* LOCK  */
  YYSYMBOL_MUT = 17,                       /* MUT  */
  YYSYMBOL_BORROW = 18,                    /* BORROW  */
  YYSYMBOL_NEW = 19,                       /* NEW  */
  YYSYMBOL_SELF = 20,                      /* SELF  */
  YYSYMBOL_SUPER = 21,                     /* SUPER  */
  YYSYMBOL_USING = 22,                     /* USING  */
  YYSYMBOL_SWITCH = 23,                    /* SWITCH  */
  YYSYMBOL_CASE = 24,                      /* CASE  */
  YYSYMBOL_MATCH = 25,                     /* MATCH  */
  YYSYMBOL_UNSAFE = 26,                    /* UNSAFE  */
  YYSYMBOL_FOR = 27,                       /* FOR  */
  YYSYMBOL_IN = 28,                        /* IN  */
  YYSYMBOL_RETURN = 29,                    /* RETURN  */
  YYSYMBOL_IF = 30,                        /* IF  */
  YYSYMBOL_ELSE = 31,                      /* ELSE  */
  YYSYMBOL_THREAD = 32,                    /* THREAD  */
  YYSYMBOL_RUN = 33,                       /* RUN  */
  YYSYMBOL_MEM = 34,                       /* MEM  */
  YYSYMBOL_ALLOC = 35,                     /* ALLOC  */
  YYSYMBOL_SIZEOF = 36,                    /* SIZEOF  */
  YYSYMBOL_DROP = 37,                      /* DROP  */
  YYSYMBOL_FREE = 38,                      /* FREE  */
  YYSYMBOL_PLUS = 39,                      /* PLUS  */
  YYSYMBOL_MINUS = 40,                     /* MINUS  */
  YYSYMBOL_STAR = 41,                      /* STAR  */
  YYSYMBOL_SLASH = 42,                     /* SLASH  */
  YYSYMBOL_PERCENT = 43,                   /* PERCENT  */
  YYSYMBOL_PLUS_ASSIGN = 44,               /* PLUS_ASSIGN  */
  YYSYMBOL_MINUS_ASSIGN = 45,              /* MINUS_ASSIGN  */
  YYSYMBOL_STAR_ASSIGN = 46,               /* STAR_ASSIGN  */
  YYSYMBOL_SLASH_ASSIGN = 47,              /* SLASH_ASSIGN  */
  YYSYMBOL_EQ = 48,                        /* EQ  */
  YYSYMBOL_NEQ = 49,                       /* NEQ  */
  YYSYMBOL_LT = 50,                        /* LT  */
  YYSYMBOL_GT = 51,                        /* GT  */
  YYSYMBOL_LTE = 52,                       /* LTE  */
  YYSYMBOL_GTE = 53,                       /* GTE  */
  YYSYMBOL_ASSIGN = 54,                    /* ASSIGN  */
  YYSYMBOL_AND = 55,                       /* AND  */
  YYSYMBOL_OR = 56,                        /* OR  */
  YYSYMBOL_NOT = 57,                       /* NOT  */
  YYSYMBOL_AMP = 58,                       /* AMP  */
  YYSYMBOL_PIPE = 59,                      /* PIPE  */
  YYSYMBOL_TILDE = 60,                     /* TILDE  */
  YYSYMBOL_RANGE = 61,                     /* RANGE  */
  YYSYMBOL_ARROW = 62,                     /* ARROW  */
  YYSYMBOL_LPAREN = 63,                    /* LPAREN  */
  YYSYMBOL_RPAREN = 64,                    /* RPAREN  */
  YYSYMBOL_LBRACE = 65,                    /* LBRACE  */
  YYSYMBOL_RBRACE = 66,                    /* RBRACE  */
  YYSYMBOL_LBRACKET = 67,                  /* LBRACKET  */
  YYSYMBOL_RBRACKET = 68,                  /* RBRACKET  */
  YYSYMBOL_SEMICOLON = 69,                 /* SEMICOLON  */
  YYSYMBOL_COLON = 70,                     /* COLON  */
  YYSYMBOL_DOT = 71,                       /* DOT  */
  YYSYMBOL_COMMA = 72,                     /* COMMA  */
  YYSYMBOL_UMINUS = 73,                    /* UMINUS  */
  YYSYMBOL_UADDR = 74,                     /* UADDR  */
  YYSYMBOL_USTAR = 75,                     /* USTAR  */
  YYSYMBOL_YYACCEPT = 76,                  /* $accept  */
  YYSYMBOL_program = 77,                   /* program  */
  YYSYMBOL_top_level_list = 78,            /* top_level_list  */
  YYSYMBOL_top_levelstmt = 79,             /* top_levelstmt  */
  YYSYMBOL_import_stmt = 80,               /* import_stmt  */
  YYSYMBOL_import_path = 81,               /* import_path  */
  YYSYMBOL_any_ident = 82,                 /* any_ident  */
  YYSYMBOL_link_stmt = 83,                 /* link_stmt  */
  YYSYMBOL_struct_def = 84,                /* struct_def  */
  YYSYMBOL_field_list = 85,                /* field_list  */
  YYSYMBOL_field = 86,                     /* field  */
  YYSYMBOL_class_def = 87,                 /* class_def  */
  YYSYMBOL_class_body = 88,                /* class_body  */
  YYSYMBOL_class_member = 89,              /* class_member  */
  YYSYMBOL_func_def = 90,                  /* func_def  */
  YYSYMBOL_param_list = 91,                /* param_list  */
  YYSYMBOL_param = 92,                     /* param  */
  YYSYMBOL_block = 93,                     /* block  */
  YYSYMBOL_stmt_list = 94,                 /* stmt_list  */
  YYSYMBOL_stmt = 95,                      /* stmt  */
  YYSYMBOL_opt_semicolon = 96,             /* opt_semicolon  */
  YYSYMBOL_decl_stmt = 97,                 /* decl_stmt  */
  YYSYMBOL_return_stmt = 98,               /* return_stmt  */
  YYSYMBOL_if_stmt = 99,                   /* if_stmt  */
  YYSYMBOL_switch_stmt = 100,              /* switch_stmt  */
  YYSYMBOL_case_list = 101,                /* case_list  */
  YYSYMBOL_case = 102,                     /* case  */
  YYSYMBOL_match_stmt = 103,               /* match_stmt  */
  YYSYMBOL_match_case_list = 104,          /* match_case_list  */
  YYSYMBOL_match_case = 105,               /* match_case  */
  YYSYMBOL_for_stmt = 106,                 /* for_stmt  */
  YYSYMBOL_using_stmt = 107,               /* using_stmt  */
  YYSYMBOL_unsafe_stmt = 108,              /* unsafe_stmt  */
  YYSYMBOL_type = 109,                     /* type  */
  YYSYMBOL_arg_list = 110,                 /* arg_list  */
  YYSYMBOL_opt_arg_list = 111,             /* opt_arg_list  */
  YYSYMBOL_expr = 112,                     /* expr  */
  YYSYMBOL_postfix_expr = 113,             /* postfix_expr  */
  YYSYMBOL_primary = 114                   /* primary  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;




#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_int16 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if !defined yyoverflow

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* !defined yyoverflow */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  56
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   1104

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  76
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  39
/* YYNRULES -- Number of rules.  */
#define YYNRULES  160
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  324

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   330


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75
};

#if YYDEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,    66,    66,    70,    77,    87,    88,    89,    90,    91,
      95,   101,   108,   114,   118,   130,   131,   132,   133,   134,
     135,   136,   137,   138,   139,   140,   141,   142,   143,   144,
     145,   146,   147,   148,   149,   150,   151,   152,   153,   154,
     155,   156,   157,   158,   159,   160,   164,   173,   180,   189,
     195,   205,   215,   222,   232,   235,   243,   244,   248,   257,
     265,   274,   285,   291,   301,   308,   317,   324,   331,   341,
     346,   352,   358,   368,   369,   370,   371,   372,   373,   374,
     375,   376,   380,   381,   385,   393,   410,   420,   428,   445,
     453,   464,   468,   475,   481,   487,   496,   511,   517,   527,
     532,   540,   555,   561,   571,   576,   581,   589,   598,   606,
     613,   614,   615,   616,   617,   621,   627,   637,   638,   642,
     643,   644,   645,   646,   647,   648,   649,   650,   651,   652,
     653,   654,   655,   656,   661,   667,   673,   679,   685,   691,
     696,   701,   706,   710,   714,   718,   723,   730,   737,   738,
     743,   761,   775,   780,   787,   794,   798,   802,   806,   807,
     819
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if YYDEBUG || 0
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "IDENTIFIER",
  "INT_LIT", "STRING_LIT", "STRING_INTERP", "IMPORT", "LINK", "AS",
  "STRUCT", "CLASS", "EXTENDS", "VOID", "INT", "STRING", "LOCK", "MUT",
  "BORROW", "NEW", "SELF", "SUPER", "USING", "SWITCH", "CASE", "MATCH",
  "UNSAFE", "FOR", "IN", "RETURN", "IF", "ELSE", "THREAD", "RUN", "MEM",
  "ALLOC", "SIZEOF", "DROP", "FREE", "PLUS", "MINUS", "STAR", "SLASH",
  "PERCENT", "PLUS_ASSIGN", "MINUS_ASSIGN", "STAR_ASSIGN", "SLASH_ASSIGN",
  "EQ", "NEQ", "LT", "GT", "LTE", "GTE", "ASSIGN", "AND", "OR", "NOT",
  "AMP", "PIPE", "TILDE", "RANGE", "ARROW", "LPAREN", "RPAREN", "LBRACE",
  "RBRACE", "LBRACKET", "RBRACKET", "SEMICOLON", "COLON", "DOT", "COMMA",
  "UMINUS", "UADDR", "USTAR", "$accept", "program", "top_level_list",
  "top_levelstmt", "import_stmt", "import_path", "any_ident", "link_stmt",
  "struct_def", "field_list", "field", "class_def", "class_body",
  "class_member", "func_def", "param_list", "param", "block", "stmt_list",
  "stmt", "opt_semicolon", "decl_stmt", "return_stmt", "if_stmt",
  "switch_stmt", "case_list", "case", "match_stmt", "match_case_list",
  "match_case", "for_stmt", "using_stmt", "unsafe_stmt", "type",
  "arg_list", "opt_arg_list", "expr", "postfix_expr", "primary", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-205)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-115)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
     234,  -205,   505,    11,    23,    80,  -205,  -205,  -205,  -205,
      89,   234,  -205,  -205,  -205,  -205,  -205,  -205,     6,  -205,
      -7,  -205,  -205,  -205,  -205,  -205,  -205,  -205,  -205,  -205,
    -205,  -205,  -205,  -205,  -205,  -205,  -205,  -205,  -205,  -205,
    -205,  -205,  -205,  -205,  -205,  -205,  -205,  -205,  -205,  -205,
    -205,    70,  -205,    36,    39,     3,  -205,  -205,    47,    48,
     124,  -205,  -205,   541,  -205,    14,   130,  -205,   176,   182,
      71,  -205,    74,    31,  -205,   139,    98,    35,   115,   167,
      99,    12,  -205,    28,    99,    30,  -205,  -205,    96,  -205,
      97,  -205,  -205,  -205,  -205,    21,   166,   168,   170,   253,
    -205,    99,   281,  -205,   175,  -205,    99,  -205,  -205,    40,
      19,  -205,  -205,    33,  -205,  -205,  -205,   115,    78,   115,
    -205,  -205,   104,   125,   138,    99,   184,     1,   399,     4,
     131,   145,   399,   399,   399,   399,   399,  -205,   309,  -205,
    -205,  -205,  -205,  -205,  -205,  -205,  -205,  -205,    57,   542,
      37,  -205,  -205,  -205,  -205,  -205,  -205,  -205,   207,   172,
     215,   158,   399,   399,   399,  -205,   208,  -205,  -205,   573,
     759,   180,   202,   100,   399,   177,   177,   177,   786,   181,
     189,  1020,  -205,  -205,   206,   258,   399,   399,   399,   399,
     399,   399,   399,   399,   399,   399,   399,   399,   399,   399,
     399,   399,   399,   399,   399,  -205,  -205,   399,   259,   210,
     399,   211,   399,   812,   838,   864,   399,  -205,   250,   399,
     223,   225,   226,   227,   890,  -205,   399,  -205,   439,   238,
     -29,   -29,   177,   177,   177,  1020,  1020,  1020,  1020,    73,
      73,   191,   191,   191,   191,  1020,   164,  1043,   177,   236,
    -205,   448,   604,   399,   237,    99,   239,   240,   759,    42,
     916,   399,   399,   115,   399,  -205,  1020,   399,   635,   399,
    -205,   399,   666,  -205,   697,  -205,  -205,   278,   279,  -205,
    -205,  -205,  -205,   942,   968,   242,   994,   241,  -205,   728,
     243,  -205,  -205,   349,   -14,  -205,   359,    -5,  -205,  -205,
    -205,  -205,  -205,   248,  -205,   251,    99,   759,  -205,  -205,
     280,    99,   759,  -205,  -205,  -205,  -205,  -205,  -205,   399,
    -205,  -205,   759,  -205
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       0,   114,     0,     0,     0,     0,   111,   110,   112,   113,
       0,     2,     4,     5,     6,     7,     8,     9,     0,    15,
       0,    45,    30,    31,    32,    25,    23,    24,    26,    27,
      28,    29,    43,    44,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    16,    17,    18,    19,    20,    21,
      22,     0,    13,     0,     0,     0,     1,     3,     0,     0,
       0,    10,    12,     0,    46,     0,     0,    55,     0,     0,
       0,    14,     0,     0,    49,     0,     0,     0,     0,     0,
       0,     0,    62,     0,     0,     0,    11,    48,     0,    50,
       0,    55,    52,    54,    57,     0,     0,    67,     0,     0,
      59,     0,     0,    64,     0,    61,     0,    47,    51,     0,
       0,    68,    66,   155,   152,   153,   154,     0,     0,     0,
     156,   157,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   117,    69,     0,    71,
      81,    74,    75,    76,    77,    78,    79,    80,     0,    83,
     119,   148,    58,    63,    65,    60,    53,    56,     0,     0,
       0,   160,     0,     0,     0,   109,     0,   155,    91,     0,
       0,     0,     0,     0,     0,   139,   140,   141,     0,   118,
       0,   115,    70,    72,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    82,    73,   117,     0,     0,
       0,     0,   117,     0,     0,     0,     0,    92,    93,     0,
       0,     0,     0,     0,     0,   158,     0,   151,     0,     0,
     120,   121,   122,   123,   124,   135,   136,   137,   138,   125,
     126,   127,   128,   129,   130,   134,   131,   132,   133,     0,
     149,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   147,   116,   117,     0,     0,
     150,   117,     0,    89,     0,   159,   108,     0,     0,   107,
      95,    94,   142,     0,     0,     0,     0,     0,    84,     0,
       0,    87,    90,     0,     0,    97,     0,     0,   102,   143,
     146,   145,   144,   151,    86,   151,     0,     0,    96,    98,
     155,     0,     0,   101,   103,    85,    88,   100,    99,     0,
     106,   105,     0,   104
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -205,  -205,  -205,   310,  -205,  -205,   270,  -205,  -205,  -205,
     264,  -205,   249,  -205,    -6,   273,   244,   -83,  -205,   212,
    -205,  -205,  -205,    85,  -205,  -205,    51,  -205,  -205,    54,
    -205,  -205,  -205,     0,  -205,  -204,   -42,  -205,  -205
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
       0,    10,    11,    12,    13,    51,    52,    14,    15,    73,
      74,    16,    77,    93,    17,    81,    82,   100,   138,   139,
     206,   140,   141,   142,   143,   294,   295,   144,   297,   298,
     145,   146,   147,    83,   179,   180,   181,   150,   151
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      18,   105,    60,   249,   167,   114,   115,   116,   254,    58,
     293,    18,   188,   189,   190,    66,    53,     1,   152,   296,
     119,   120,   121,   155,   110,    59,    54,     6,     7,     8,
       9,   103,   204,   129,     1,   130,  -114,   171,     1,   131,
      59,   132,   165,     1,     6,     7,     8,     9,     6,     7,
       8,     9,   308,     6,     7,     8,     9,   149,   133,   134,
     184,   313,    61,   287,   135,    75,   136,   290,    67,   104,
     168,    94,   128,    75,  -114,   172,   101,    95,    96,    98,
      72,   159,    68,    55,   102,   169,   170,   218,   157,    56,
     175,   176,   177,   178,   106,   160,   149,    88,   185,   148,
     207,    92,   102,    94,    65,    64,   156,    99,   208,    95,
      68,    69,   186,   187,   188,   189,   190,   158,     1,   161,
     213,   214,   215,   197,   198,   199,   200,    70,     6,     7,
       8,     9,   224,    76,   204,   221,   222,   223,   148,    62,
      86,    63,    90,    87,   230,   231,   232,   233,   234,   235,
     236,   237,   238,   239,   240,   241,   242,   243,   244,   245,
     246,   247,   248,    91,    99,   107,   108,   162,   252,   111,
      97,  -114,   276,   112,   258,   279,   280,   260,   154,     1,
       6,     7,     8,     9,   266,     1,   268,   166,   163,     6,
       7,     8,     9,    78,    79,     6,     7,     8,     9,    78,
      79,   164,   173,   186,   187,   188,   189,   190,   174,   272,
     209,   274,   195,   196,   197,   198,   199,   200,   211,   283,
     284,   212,   286,   317,   318,   204,   210,   289,   320,   321,
     186,   187,   188,   189,   190,   220,   216,     1,   204,   323,
      80,     2,     3,   219,     4,     5,    84,     6,     7,     8,
       9,   307,   204,   226,   312,   227,   113,   114,   115,   116,
     228,   229,   250,   285,   251,   253,     6,     7,     8,     9,
     117,   118,   119,   120,   121,   122,   123,   322,   124,   125,
     126,   259,   127,   128,     1,   129,   261,   130,   262,   263,
     264,   131,   269,   132,     6,     7,     8,     9,    78,    79,
     270,   275,   293,   296,   277,   278,   301,   303,   319,   305,
     133,   134,   113,   114,   115,   116,   135,   315,   136,   137,
     316,    57,     6,     7,     8,     9,   117,   118,   119,   120,
     121,   122,   123,    71,   124,   125,   126,    89,   127,   128,
     109,   129,    85,   130,   281,   309,   153,   131,     0,   132,
     183,   314,   167,   114,   115,   116,     0,     0,     0,     0,
       0,     0,   310,   114,   115,   116,   133,   134,   119,   120,
     121,     0,   135,     0,   136,   182,     0,     0,   119,   120,
     121,   129,     0,   130,     0,     0,     0,   131,     0,   132,
     306,   129,     0,   130,     0,     0,     0,   131,     0,   132,
     311,     0,   167,   114,   115,   116,   133,   134,     0,     0,
       0,     0,   135,     0,   136,     0,   133,   134,   119,   120,
     121,     0,   135,     0,   136,     0,     0,     0,     0,     0,
       0,   129,     0,   130,     0,     0,     0,   131,     0,   132,
       0,     0,   167,   114,   115,   116,     0,     0,     0,     0,
       0,   167,   114,   115,   116,     0,   133,   134,   119,   120,
     121,     0,   135,     0,   136,     0,     0,   119,   120,   121,
       0,   129,     0,   130,     0,     0,     0,   131,     0,   132,
     129,     0,   130,     0,     0,     0,   131,     0,   132,     0,
       0,     0,     0,     0,     0,     0,   133,   134,     0,     0,
       0,     0,   135,     0,   267,   133,   134,     0,    19,     0,
      20,   135,     0,   271,    21,    22,    23,    24,    25,    26,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    41,    42,    43,    44,    45,    46,
      47,    48,    49,    50,    19,     0,     0,     0,     0,     0,
      21,    22,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
       0,   186,   187,   188,   189,   190,   191,   192,   193,   194,
     195,   196,   197,   198,   199,   200,   201,   202,   203,     0,
       0,     0,     0,   204,     0,     0,     0,     0,     0,     0,
       0,   205,   186,   187,   188,   189,   190,   191,   192,   193,
     194,   195,   196,   197,   198,   199,   200,   201,   202,   203,
       0,     0,     0,     0,   204,     0,     0,     0,     0,     0,
       0,     0,   217,   186,   187,   188,   189,   190,   191,   192,
     193,   194,   195,   196,   197,   198,   199,   200,   201,   202,
     203,     0,     0,     0,     0,   204,     0,     0,     0,     0,
       0,     0,     0,   273,   186,   187,   188,   189,   190,   191,
     192,   193,   194,   195,   196,   197,   198,   199,   200,   201,
     202,   203,     0,     0,     0,     0,   204,     0,     0,     0,
       0,     0,     0,     0,   288,   186,   187,   188,   189,   190,
     191,   192,   193,   194,   195,   196,   197,   198,   199,   200,
     201,   202,   203,     0,     0,     0,     0,   204,     0,     0,
       0,     0,     0,     0,     0,   291,   186,   187,   188,   189,
     190,   191,   192,   193,   194,   195,   196,   197,   198,   199,
     200,   201,   202,   203,     0,     0,     0,     0,   204,     0,
       0,     0,     0,     0,     0,     0,   292,   186,   187,   188,
     189,   190,   191,   192,   193,   194,   195,   196,   197,   198,
     199,   200,   201,   202,   203,     0,     0,     0,     0,   204,
       0,     0,     0,     0,     0,     0,     0,   304,   186,   187,
     188,   189,   190,   191,   192,   193,   194,   195,   196,   197,
     198,   199,   200,   201,   202,   203,     0,     0,     0,     0,
     204,     0,     0,     0,    99,   186,   187,   188,   189,   190,
     191,   192,   193,   194,   195,   196,   197,   198,   199,   200,
     201,   202,   203,     0,     0,     0,     0,   204,     0,     0,
     225,   186,   187,   188,   189,   190,   191,   192,   193,   194,
     195,   196,   197,   198,   199,   200,   201,   202,   203,     0,
       0,     0,     0,   204,     0,     0,   255,   186,   187,   188,
     189,   190,   191,   192,   193,   194,   195,   196,   197,   198,
     199,   200,   201,   202,   203,     0,     0,     0,     0,   204,
       0,     0,   256,   186,   187,   188,   189,   190,   191,   192,
     193,   194,   195,   196,   197,   198,   199,   200,   201,   202,
     203,     0,     0,     0,     0,   204,     0,     0,   257,   186,
     187,   188,   189,   190,   191,   192,   193,   194,   195,   196,
     197,   198,   199,   200,   201,   202,   203,     0,     0,     0,
       0,   204,     0,     0,   265,   186,   187,   188,   189,   190,
     191,   192,   193,   194,   195,   196,   197,   198,   199,   200,
     201,   202,   203,     0,     0,     0,     0,   204,     0,     0,
     282,   186,   187,   188,   189,   190,   191,   192,   193,   194,
     195,   196,   197,   198,   199,   200,   201,   202,   203,     0,
       0,     0,     0,   204,     0,     0,   299,   186,   187,   188,
     189,   190,   191,   192,   193,   194,   195,   196,   197,   198,
     199,   200,   201,   202,   203,     0,     0,     0,     0,   204,
       0,     0,   300,   186,   187,   188,   189,   190,   191,   192,
     193,   194,   195,   196,   197,   198,   199,   200,   201,   202,
     203,     0,     0,     0,     0,   204,     0,     0,   302,   186,
     187,   188,   189,   190,   191,   192,   193,   194,   195,   196,
     197,   198,   199,   200,   201,   202,   203,     0,     0,     0,
       0,   204,   186,   187,   188,   189,   190,     0,     0,     0,
       0,   195,   196,   197,   198,   199,   200,     0,   202,     0,
       0,     0,     0,     0,   204
};

static const yytype_int16 yycheck[] =
{
       0,    84,     9,   207,     3,     4,     5,     6,   212,     3,
      24,    11,    41,    42,    43,    12,     5,     3,   101,    24,
      19,    20,    21,   106,     3,    19,     3,    13,    14,    15,
      16,     3,    61,    32,     3,    34,     3,    33,     3,    38,
      19,    40,   125,     3,    13,    14,    15,    16,    13,    14,
      15,    16,    66,    13,    14,    15,    16,    99,    57,    58,
       3,    66,    69,   267,    63,    65,    65,   271,    65,    41,
      69,    77,    30,    73,    41,    71,    64,    77,    78,    79,
      66,     3,    63,     3,    72,   127,   128,   170,    69,     0,
     132,   133,   134,   135,    64,    17,   138,    66,    41,    99,
      63,    66,    72,   109,    65,    69,    66,    65,    71,   109,
      63,    63,    39,    40,    41,    42,    43,   117,     3,   119,
     162,   163,   164,    50,    51,    52,    53,     3,    13,    14,
      15,    16,   174,     3,    61,    35,    36,    37,   138,    69,
      69,    71,     3,    69,   186,   187,   188,   189,   190,   191,
     192,   193,   194,   195,   196,   197,   198,   199,   200,   201,
     202,   203,   204,    65,    65,    69,    69,    63,   210,     3,
       3,     3,   255,     3,   216,   258,   259,   219,     3,     3,
      13,    14,    15,    16,   226,     3,   228,     3,    63,    13,
      14,    15,    16,    17,    18,    13,    14,    15,    16,    17,
      18,    63,    71,    39,    40,    41,    42,    43,    63,   251,
       3,   253,    48,    49,    50,    51,    52,    53,     3,   261,
     262,    63,   264,   306,   307,    61,    54,   269,   311,   312,
      39,    40,    41,    42,    43,    33,    28,     3,    61,   322,
      64,     7,     8,    63,    10,    11,    64,    13,    14,    15,
      16,   293,    61,    72,   296,    66,     3,     4,     5,     6,
      54,     3,     3,   263,    54,    54,    13,    14,    15,    16,
      17,    18,    19,    20,    21,    22,    23,   319,    25,    26,
      27,    31,    29,    30,     3,    32,    63,    34,    63,    63,
      63,    38,    54,    40,    13,    14,    15,    16,    17,    18,
      64,    64,    24,    24,    65,    65,    64,    66,    28,    66,
      57,    58,     3,     4,     5,     6,    63,    69,    65,    66,
      69,    11,    13,    14,    15,    16,    17,    18,    19,    20,
      21,    22,    23,    63,    25,    26,    27,    73,    29,    30,
      91,    32,    69,    34,   259,   294,   102,    38,    -1,    40,
     138,   297,     3,     4,     5,     6,    -1,    -1,    -1,    -1,
      -1,    -1,     3,     4,     5,     6,    57,    58,    19,    20,
      21,    -1,    63,    -1,    65,    66,    -1,    -1,    19,    20,
      21,    32,    -1,    34,    -1,    -1,    -1,    38,    -1,    40,
      41,    32,    -1,    34,    -1,    -1,    -1,    38,    -1,    40,
      41,    -1,     3,     4,     5,     6,    57,    58,    -1,    -1,
      -1,    -1,    63,    -1,    65,    -1,    57,    58,    19,    20,
      21,    -1,    63,    -1,    65,    -1,    -1,    -1,    -1,    -1,
      -1,    32,    -1,    34,    -1,    -1,    -1,    38,    -1,    40,
      -1,    -1,     3,     4,     5,     6,    -1,    -1,    -1,    -1,
      -1,     3,     4,     5,     6,    -1,    57,    58,    19,    20,
      21,    -1,    63,    -1,    65,    -1,    -1,    19,    20,    21,
      -1,    32,    -1,    34,    -1,    -1,    -1,    38,    -1,    40,
      32,    -1,    34,    -1,    -1,    -1,    38,    -1,    40,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    57,    58,    -1,    -1,
      -1,    -1,    63,    -1,    65,    57,    58,    -1,     3,    -1,
       5,    63,    -1,    65,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,     3,    -1,    -1,    -1,    -1,    -1,
       9,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
      -1,    39,    40,    41,    42,    43,    44,    45,    46,    47,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    -1,
      -1,    -1,    -1,    61,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    69,    39,    40,    41,    42,    43,    44,    45,    46,
      47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
      -1,    -1,    -1,    -1,    61,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    69,    39,    40,    41,    42,    43,    44,    45,
      46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    -1,    -1,    -1,    -1,    61,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    69,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    -1,    -1,    -1,    -1,    61,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    69,    39,    40,    41,    42,    43,
      44,    45,    46,    47,    48,    49,    50,    51,    52,    53,
      54,    55,    56,    -1,    -1,    -1,    -1,    61,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    69,    39,    40,    41,    42,
      43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    56,    -1,    -1,    -1,    -1,    61,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    69,    39,    40,    41,
      42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    -1,    -1,    -1,    -1,    61,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    69,    39,    40,
      41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    56,    -1,    -1,    -1,    -1,
      61,    -1,    -1,    -1,    65,    39,    40,    41,    42,    43,
      44,    45,    46,    47,    48,    49,    50,    51,    52,    53,
      54,    55,    56,    -1,    -1,    -1,    -1,    61,    -1,    -1,
      64,    39,    40,    41,    42,    43,    44,    45,    46,    47,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    -1,
      -1,    -1,    -1,    61,    -1,    -1,    64,    39,    40,    41,
      42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    -1,    -1,    -1,    -1,    61,
      -1,    -1,    64,    39,    40,    41,    42,    43,    44,    45,
      46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    -1,    -1,    -1,    -1,    61,    -1,    -1,    64,    39,
      40,    41,    42,    43,    44,    45,    46,    47,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    -1,    -1,    -1,
      -1,    61,    -1,    -1,    64,    39,    40,    41,    42,    43,
      44,    45,    46,    47,    48,    49,    50,    51,    52,    53,
      54,    55,    56,    -1,    -1,    -1,    -1,    61,    -1,    -1,
      64,    39,    40,    41,    42,    43,    44,    45,    46,    47,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    -1,
      -1,    -1,    -1,    61,    -1,    -1,    64,    39,    40,    41,
      42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    -1,    -1,    -1,    -1,    61,
      -1,    -1,    64,    39,    40,    41,    42,    43,    44,    45,
      46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    -1,    -1,    -1,    -1,    61,    -1,    -1,    64,    39,
      40,    41,    42,    43,    44,    45,    46,    47,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    -1,    -1,    -1,
      -1,    61,    39,    40,    41,    42,    43,    -1,    -1,    -1,
      -1,    48,    49,    50,    51,    52,    53,    -1,    55,    -1,
      -1,    -1,    -1,    -1,    61
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_int8 yystos[] =
{
       0,     3,     7,     8,    10,    11,    13,    14,    15,    16,
      77,    78,    79,    80,    83,    84,    87,    90,   109,     3,
       5,     9,    10,    11,    12,    13,    14,    15,    16,    17,
      18,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    33,    34,    35,    36,    37,
      38,    81,    82,     5,     3,     3,     0,    79,     3,    19,
       9,    69,    69,    71,    69,    65,    12,    65,    63,    63,
       3,    82,    66,    85,    86,   109,     3,    88,    17,    18,
      64,    91,    92,   109,    64,    91,    69,    69,    66,    86,
       3,    65,    66,    89,    90,   109,   109,     3,   109,    65,
      93,    64,    72,     3,    41,    93,    64,    69,    69,    88,
       3,     3,     3,     3,     4,     5,     6,    17,    18,    19,
      20,    21,    22,    23,    25,    26,    27,    29,    30,    32,
      34,    38,    40,    57,    58,    63,    65,    66,    94,    95,
      97,    98,    99,   100,   103,   106,   107,   108,   109,   112,
     113,   114,    93,    92,     3,    93,    66,    69,   109,     3,
      17,   109,    63,    63,    63,    93,     3,     3,    69,   112,
     112,    33,    71,    71,    63,   112,   112,   112,   112,   110,
     111,   112,    66,    95,     3,    41,    39,    40,    41,    42,
      43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    56,    61,    69,    96,    63,    71,     3,
      54,     3,    63,   112,   112,   112,    28,    69,    93,    63,
      33,    35,    36,    37,   112,    64,    72,    66,    54,     3,
     112,   112,   112,   112,   112,   112,   112,   112,   112,   112,
     112,   112,   112,   112,   112,   112,   112,   112,   112,   111,
       3,    54,   112,    54,   111,    64,    64,    64,   112,    31,
     112,    63,    63,    63,    63,    64,   112,    65,   112,    54,
      64,    65,   112,    69,   112,    64,    93,    65,    65,    93,
      93,    99,    64,   112,   112,   109,   112,   111,    69,   112,
     111,    69,    69,    24,   101,   102,    24,   104,   105,    64,
      64,    64,    64,    66,    69,    66,    41,   112,    66,   102,
       3,    41,   112,    66,   105,    69,    69,    93,    93,    28,
      93,    93,   112,    93
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr1[] =
{
       0,    76,    77,    78,    78,    79,    79,    79,    79,    79,
      80,    80,    80,    81,    81,    82,    82,    82,    82,    82,
      82,    82,    82,    82,    82,    82,    82,    82,    82,    82,
      82,    82,    82,    82,    82,    82,    82,    82,    82,    82,
      82,    82,    82,    82,    82,    82,    83,    84,    84,    85,
      85,    86,    87,    87,    88,    88,    89,    89,    90,    90,
      90,    90,    91,    91,    92,    92,    92,    92,    92,    93,
      93,    94,    94,    95,    95,    95,    95,    95,    95,    95,
      95,    95,    96,    96,    97,    97,    97,    97,    97,    97,
      97,    98,    98,    99,    99,    99,   100,   101,   101,   102,
     102,   103,   104,   104,   105,   105,   105,   106,   107,   108,
     109,   109,   109,   109,   109,   110,   110,   111,   111,   112,
     112,   112,   112,   112,   112,   112,   112,   112,   112,   112,
     112,   112,   112,   112,   112,   112,   112,   112,   112,   112,
     112,   112,   112,   112,   112,   112,   112,   112,   113,   113,
     113,   113,   114,   114,   114,   114,   114,   114,   114,   114,
     114
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     1,     2,     1,     1,     1,     1,     1,     1,
       3,     5,     3,     1,     3,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     3,     6,     5,     1,
       2,     3,     5,     7,     2,     0,     3,     1,     6,     5,
       6,     5,     1,     3,     2,     3,     3,     2,     3,     2,
       3,     1,     2,     2,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     0,     5,     7,     6,     6,     8,     5,
       6,     2,     3,     3,     5,     5,     7,     1,     2,     3,
       3,     7,     1,     2,     5,     3,     3,     5,     5,     2,
       1,     1,     1,     1,     1,     1,     3,     0,     1,     1,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     2,
       2,     2,     5,     6,     6,     6,     6,     4,     1,     3,
       4,     3,     1,     1,     1,     1,     1,     1,     3,     5,
       2
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use YYerror or YYUNDEF. */
#define YYERRCODE YYUNDEF


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)




# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  yy_symbol_value_print (yyo, yykind, yyvaluep);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp,
                 int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)]);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif






/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep)
{
  YY_USE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/* Lookahead token kind.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;




/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY; /* Cause a token to be read.  */

  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2: /* program: top_level_list  */
#line 66 "parser.y"
                     { program_root = (yyvsp[0].node); }
#line 1567 "parser.tab.c"
    break;

  case 3: /* top_level_list: top_level_list top_levelstmt  */
#line 70 "parser.y"
                                   {
        AstNode *prog = (yyvsp[-1].node);
        prog->data.block.stmts = realloc(prog->data.block.stmts,
            sizeof(AstNode*) * (prog->data.block.stmt_count + 1));
        prog->data.block.stmts[prog->data.block.stmt_count++] = (yyvsp[0].node);
        (yyval.node) = prog;
    }
#line 1579 "parser.tab.c"
    break;

  case 4: /* top_level_list: top_levelstmt  */
#line 77 "parser.y"
                    {
        AstNode *prog = ast_create_node(NODE_PROGRAM, yylineno, yycolumn);
        prog->data.block.stmts = malloc(sizeof(AstNode*));
        prog->data.block.stmts[0] = (yyvsp[0].node);
        prog->data.block.stmt_count = 1;
        (yyval.node) = prog;
    }
#line 1591 "parser.tab.c"
    break;

  case 5: /* top_levelstmt: import_stmt  */
#line 87 "parser.y"
                  { (yyval.node) = (yyvsp[0].node); }
#line 1597 "parser.tab.c"
    break;

  case 6: /* top_levelstmt: link_stmt  */
#line 88 "parser.y"
                { (yyval.node) = (yyvsp[0].node); }
#line 1603 "parser.tab.c"
    break;

  case 7: /* top_levelstmt: struct_def  */
#line 89 "parser.y"
                 { (yyval.node) = (yyvsp[0].node); }
#line 1609 "parser.tab.c"
    break;

  case 8: /* top_levelstmt: class_def  */
#line 90 "parser.y"
                { (yyval.node) = (yyvsp[0].node); }
#line 1615 "parser.tab.c"
    break;

  case 9: /* top_levelstmt: func_def  */
#line 91 "parser.y"
               { (yyval.node) = (yyvsp[0].node); }
#line 1621 "parser.tab.c"
    break;

  case 10: /* import_stmt: IMPORT STRING_LIT SEMICOLON  */
#line 95 "parser.y"
                                  {
        (yyval.node) = ast_create_node(NODE_IMPORT, yylineno, yycolumn);
        char *s = (yyvsp[-1].string_val);
        s++; s[strlen(s)-1] = '\0';
        (yyval.node)->data.import.name = strdup(s);
    }
#line 1632 "parser.tab.c"
    break;

  case 11: /* import_stmt: IMPORT STRING_LIT AS IDENTIFIER SEMICOLON  */
#line 101 "parser.y"
                                                {
        (yyval.node) = ast_create_node(NODE_IMPORT, yylineno, yycolumn);
        char *s = (yyvsp[-3].string_val);
        s++; s[strlen(s)-1] = '\0';
        (yyval.node)->data.import.name = strdup(s);
        (yyval.node)->data.import.alias = (yyvsp[-1].string_val);
    }
#line 1644 "parser.tab.c"
    break;

  case 12: /* import_stmt: IMPORT import_path SEMICOLON  */
#line 108 "parser.y"
                                   {
        (yyval.node) = (yyvsp[-1].node);
    }
#line 1652 "parser.tab.c"
    break;

  case 13: /* import_path: any_ident  */
#line 114 "parser.y"
                {
        (yyval.node) = ast_create_node(NODE_IMPORT, yylineno, yycolumn);
        (yyval.node)->data.import.name = (yyvsp[0].string_val);
    }
#line 1661 "parser.tab.c"
    break;

  case 14: /* import_path: import_path DOT any_ident  */
#line 118 "parser.y"
                                {
        (yyval.node) = (yyvsp[-2].node);
        size_t len = strlen((yyval.node)->data.import.name) + 1 + strlen((yyvsp[0].string_val)) + 1;
        char *buf = malloc(len);
        snprintf(buf, len, "%s.%s", (yyval.node)->data.import.name, (yyvsp[0].string_val));
        free((yyval.node)->data.import.name);
        free((yyvsp[0].string_val));
        (yyval.node)->data.import.name = buf;
    }
#line 1675 "parser.tab.c"
    break;

  case 15: /* any_ident: IDENTIFIER  */
#line 130 "parser.y"
                 { (yyval.string_val) = (yyvsp[0].string_val); }
#line 1681 "parser.tab.c"
    break;

  case 16: /* any_ident: THREAD  */
#line 131 "parser.y"
             { (yyval.string_val) = strdup("thread"); }
#line 1687 "parser.tab.c"
    break;

  case 17: /* any_ident: RUN  */
#line 132 "parser.y"
          { (yyval.string_val) = strdup("run"); }
#line 1693 "parser.tab.c"
    break;

  case 18: /* any_ident: MEM  */
#line 133 "parser.y"
          { (yyval.string_val) = strdup("mem"); }
#line 1699 "parser.tab.c"
    break;

  case 19: /* any_ident: ALLOC  */
#line 134 "parser.y"
            { (yyval.string_val) = strdup("alloc"); }
#line 1705 "parser.tab.c"
    break;

  case 20: /* any_ident: SIZEOF  */
#line 135 "parser.y"
             { (yyval.string_val) = strdup("sizeof"); }
#line 1711 "parser.tab.c"
    break;

  case 21: /* any_ident: DROP  */
#line 136 "parser.y"
           { (yyval.string_val) = strdup("drop"); }
#line 1717 "parser.tab.c"
    break;

  case 22: /* any_ident: FREE  */
#line 137 "parser.y"
           { (yyval.string_val) = strdup("free"); }
#line 1723 "parser.tab.c"
    break;

  case 23: /* any_ident: INT  */
#line 138 "parser.y"
          { (yyval.string_val) = strdup("int"); }
#line 1729 "parser.tab.c"
    break;

  case 24: /* any_ident: STRING  */
#line 139 "parser.y"
             { (yyval.string_val) = strdup("string"); }
#line 1735 "parser.tab.c"
    break;

  case 25: /* any_ident: VOID  */
#line 140 "parser.y"
           { (yyval.string_val) = strdup("void"); }
#line 1741 "parser.tab.c"
    break;

  case 26: /* any_ident: LOCK  */
#line 141 "parser.y"
           { (yyval.string_val) = strdup("lock"); }
#line 1747 "parser.tab.c"
    break;

  case 27: /* any_ident: MUT  */
#line 142 "parser.y"
          { (yyval.string_val) = strdup("mut"); }
#line 1753 "parser.tab.c"
    break;

  case 28: /* any_ident: BORROW  */
#line 143 "parser.y"
             { (yyval.string_val) = strdup("borrow"); }
#line 1759 "parser.tab.c"
    break;

  case 29: /* any_ident: NEW  */
#line 144 "parser.y"
          { (yyval.string_val) = strdup("new"); }
#line 1765 "parser.tab.c"
    break;

  case 30: /* any_ident: STRUCT  */
#line 145 "parser.y"
             { (yyval.string_val) = strdup("struct"); }
#line 1771 "parser.tab.c"
    break;

  case 31: /* any_ident: CLASS  */
#line 146 "parser.y"
            { (yyval.string_val) = strdup("class"); }
#line 1777 "parser.tab.c"
    break;

  case 32: /* any_ident: EXTENDS  */
#line 147 "parser.y"
              { (yyval.string_val) = strdup("extends"); }
#line 1783 "parser.tab.c"
    break;

  case 33: /* any_ident: USING  */
#line 148 "parser.y"
            { (yyval.string_val) = strdup("using"); }
#line 1789 "parser.tab.c"
    break;

  case 34: /* any_ident: SWITCH  */
#line 149 "parser.y"
             { (yyval.string_val) = strdup("switch"); }
#line 1795 "parser.tab.c"
    break;

  case 35: /* any_ident: CASE  */
#line 150 "parser.y"
           { (yyval.string_val) = strdup("case"); }
#line 1801 "parser.tab.c"
    break;

  case 36: /* any_ident: MATCH  */
#line 151 "parser.y"
            { (yyval.string_val) = strdup("match"); }
#line 1807 "parser.tab.c"
    break;

  case 37: /* any_ident: UNSAFE  */
#line 152 "parser.y"
             { (yyval.string_val) = strdup("unsafe"); }
#line 1813 "parser.tab.c"
    break;

  case 38: /* any_ident: FOR  */
#line 153 "parser.y"
          { (yyval.string_val) = strdup("for"); }
#line 1819 "parser.tab.c"
    break;

  case 39: /* any_ident: IN  */
#line 154 "parser.y"
         { (yyval.string_val) = strdup("in"); }
#line 1825 "parser.tab.c"
    break;

  case 40: /* any_ident: RETURN  */
#line 155 "parser.y"
             { (yyval.string_val) = strdup("return"); }
#line 1831 "parser.tab.c"
    break;

  case 41: /* any_ident: IF  */
#line 156 "parser.y"
         { (yyval.string_val) = strdup("if"); }
#line 1837 "parser.tab.c"
    break;

  case 42: /* any_ident: ELSE  */
#line 157 "parser.y"
           { (yyval.string_val) = strdup("else"); }
#line 1843 "parser.tab.c"
    break;

  case 43: /* any_ident: SELF  */
#line 158 "parser.y"
           { (yyval.string_val) = strdup("self"); }
#line 1849 "parser.tab.c"
    break;

  case 44: /* any_ident: SUPER  */
#line 159 "parser.y"
            { (yyval.string_val) = strdup("super"); }
#line 1855 "parser.tab.c"
    break;

  case 45: /* any_ident: AS  */
#line 160 "parser.y"
         { (yyval.string_val) = strdup("as"); }
#line 1861 "parser.tab.c"
    break;

  case 46: /* link_stmt: LINK STRING_LIT SEMICOLON  */
#line 164 "parser.y"
                                {
        (yyval.node) = ast_create_node(NODE_LINK, yylineno, yycolumn);
        char *s = (yyvsp[-1].string_val);
        s++; s[strlen(s)-1] = '\0';
        (yyval.node)->data.link.path = strdup(s);
    }
#line 1872 "parser.tab.c"
    break;

  case 47: /* struct_def: STRUCT IDENTIFIER LBRACE field_list RBRACE SEMICOLON  */
#line 173 "parser.y"
                                                           {
        (yyval.node) = ast_create_node(NODE_STRUCT_DEF, yylineno, yycolumn);
        (yyval.node)->data.struct_def.name = (yyvsp[-4].string_val);
        (yyval.node)->data.struct_def.fields = (yyvsp[-2].node)->data.block.stmts;
        (yyval.node)->data.struct_def.field_count = (yyvsp[-2].node)->data.block.stmt_count;
        free((yyvsp[-2].node));
    }
#line 1884 "parser.tab.c"
    break;

  case 48: /* struct_def: STRUCT IDENTIFIER LBRACE RBRACE SEMICOLON  */
#line 180 "parser.y"
                                                {
        (yyval.node) = ast_create_node(NODE_STRUCT_DEF, yylineno, yycolumn);
        (yyval.node)->data.struct_def.name = (yyvsp[-3].string_val);
        (yyval.node)->data.struct_def.fields = NULL;
        (yyval.node)->data.struct_def.field_count = 0;
    }
#line 1895 "parser.tab.c"
    break;

  case 49: /* field_list: field  */
#line 189 "parser.y"
            {
        (yyval.node) = ast_create_node(NODE_BLOCK, yylineno, yycolumn);
        (yyval.node)->data.block.stmts = malloc(sizeof(AstNode*));
        (yyval.node)->data.block.stmts[0] = (yyvsp[0].node);
        (yyval.node)->data.block.stmt_count = 1;
    }
#line 1906 "parser.tab.c"
    break;

  case 50: /* field_list: field_list field  */
#line 195 "parser.y"
                       {
        AstNode *blk = (yyvsp[-1].node);
        blk->data.block.stmts = realloc(blk->data.block.stmts,
            sizeof(AstNode*) * (blk->data.block.stmt_count + 1));
        blk->data.block.stmts[blk->data.block.stmt_count++] = (yyvsp[0].node);
        (yyval.node) = blk;
    }
#line 1918 "parser.tab.c"
    break;

  case 51: /* field: type IDENTIFIER SEMICOLON  */
#line 205 "parser.y"
                                {
        (yyval.node) = ast_create_node(NODE_FUNC_PARAM, yylineno, yycolumn);
        (yyval.node)->data.func_param.type = (yyvsp[-2].node);
        (yyval.node)->data.func_param.name = (yyvsp[-1].string_val);
        (yyval.node)->data.func_param.is_borrow = 0;
        (yyval.node)->data.func_param.is_mut = 0;
    }
#line 1930 "parser.tab.c"
    break;

  case 52: /* class_def: CLASS IDENTIFIER LBRACE class_body RBRACE  */
#line 215 "parser.y"
                                                {
        (yyval.node) = ast_create_node(NODE_CLASS_DEF, yylineno, yycolumn);
        (yyval.node)->data.class_def.name = (yyvsp[-3].string_val);
        (yyval.node)->data.class_def.parent = NULL;
        (yyval.node)->data.class_def.members = NULL;
        (yyval.node)->data.class_def.member_count = 0;
    }
#line 1942 "parser.tab.c"
    break;

  case 53: /* class_def: CLASS IDENTIFIER EXTENDS IDENTIFIER LBRACE class_body RBRACE  */
#line 222 "parser.y"
                                                                   {
        (yyval.node) = ast_create_node(NODE_CLASS_DEF, yylineno, yycolumn);
        (yyval.node)->data.class_def.name = (yyvsp[-5].string_val);
        (yyval.node)->data.class_def.parent = (yyvsp[-3].string_val);
        (yyval.node)->data.class_def.members = NULL;
        (yyval.node)->data.class_def.member_count = 0;
    }
#line 1954 "parser.tab.c"
    break;

  case 54: /* class_body: class_body class_member  */
#line 232 "parser.y"
                              {
        (yyval.node) = (yyvsp[-1].node);
    }
#line 1962 "parser.tab.c"
    break;

  case 55: /* class_body: %empty  */
#line 235 "parser.y"
      {
        (yyval.node) = ast_create_node(NODE_BLOCK, yylineno, yycolumn);
        (yyval.node)->data.block.stmts = NULL;
        (yyval.node)->data.block.stmt_count = 0;
    }
#line 1972 "parser.tab.c"
    break;

  case 58: /* func_def: type IDENTIFIER LPAREN param_list RPAREN block  */
#line 248 "parser.y"
                                                     {
        (yyval.node) = ast_create_node(NODE_FUNC_DEF, yylineno, yycolumn);
        (yyval.node)->data.func_def.return_type = (yyvsp[-5].node);
        (yyval.node)->data.func_def.name = (yyvsp[-4].string_val);
        (yyval.node)->data.func_def.params = (yyvsp[-2].node)->data.block.stmts;
        (yyval.node)->data.func_def.param_count = (yyvsp[-2].node)->data.block.stmt_count;
        free((yyvsp[-2].node));
        (yyval.node)->data.func_def.body = (yyvsp[0].node);
    }
#line 1986 "parser.tab.c"
    break;

  case 59: /* func_def: type IDENTIFIER LPAREN RPAREN block  */
#line 257 "parser.y"
                                          {
        (yyval.node) = ast_create_node(NODE_FUNC_DEF, yylineno, yycolumn);
        (yyval.node)->data.func_def.return_type = (yyvsp[-4].node);
        (yyval.node)->data.func_def.name = (yyvsp[-3].string_val);
        (yyval.node)->data.func_def.params = NULL;
        (yyval.node)->data.func_def.param_count = 0;
        (yyval.node)->data.func_def.body = (yyvsp[0].node);
    }
#line 1999 "parser.tab.c"
    break;

  case 60: /* func_def: type NEW LPAREN param_list RPAREN block  */
#line 265 "parser.y"
                                              {
        (yyval.node) = ast_create_node(NODE_FUNC_DEF, yylineno, yycolumn);
        (yyval.node)->data.func_def.return_type = (yyvsp[-5].node);
        (yyval.node)->data.func_def.name = strdup("new");
        (yyval.node)->data.func_def.params = (yyvsp[-2].node)->data.block.stmts;
        (yyval.node)->data.func_def.param_count = (yyvsp[-2].node)->data.block.stmt_count;
        free((yyvsp[-2].node));
        (yyval.node)->data.func_def.body = (yyvsp[0].node);
    }
#line 2013 "parser.tab.c"
    break;

  case 61: /* func_def: type NEW LPAREN RPAREN block  */
#line 274 "parser.y"
                                   {
        (yyval.node) = ast_create_node(NODE_FUNC_DEF, yylineno, yycolumn);
        (yyval.node)->data.func_def.return_type = (yyvsp[-4].node);
        (yyval.node)->data.func_def.name = strdup("new");
        (yyval.node)->data.func_def.params = NULL;
        (yyval.node)->data.func_def.param_count = 0;
        (yyval.node)->data.func_def.body = (yyvsp[0].node);
    }
#line 2026 "parser.tab.c"
    break;

  case 62: /* param_list: param  */
#line 285 "parser.y"
            {
        (yyval.node) = ast_create_node(NODE_BLOCK, yylineno, yycolumn);
        (yyval.node)->data.block.stmts = malloc(sizeof(AstNode*));
        (yyval.node)->data.block.stmts[0] = (yyvsp[0].node);
        (yyval.node)->data.block.stmt_count = 1;
    }
#line 2037 "parser.tab.c"
    break;

  case 63: /* param_list: param_list COMMA param  */
#line 291 "parser.y"
                             {
        AstNode *blk = (yyvsp[-2].node);
        blk->data.block.stmts = realloc(blk->data.block.stmts,
            sizeof(AstNode*) * (blk->data.block.stmt_count + 1));
        blk->data.block.stmts[blk->data.block.stmt_count++] = (yyvsp[0].node);
        (yyval.node) = blk;
    }
#line 2049 "parser.tab.c"
    break;

  case 64: /* param: type IDENTIFIER  */
#line 301 "parser.y"
                      {
        (yyval.node) = ast_create_node(NODE_FUNC_PARAM, yylineno, yycolumn);
        (yyval.node)->data.func_param.type = (yyvsp[-1].node);
        (yyval.node)->data.func_param.name = (yyvsp[0].string_val);
        (yyval.node)->data.func_param.is_borrow = 0;
        (yyval.node)->data.func_param.is_mut = 0;
    }
#line 2061 "parser.tab.c"
    break;

  case 65: /* param: type STAR IDENTIFIER  */
#line 308 "parser.y"
                           {
        (yyval.node) = ast_create_node(NODE_FUNC_PARAM, yylineno, yycolumn);
        (yyval.node)->data.func_param.type = (yyvsp[-2].node);
        (yyval.node)->data.func_param.name = (yyvsp[0].string_val);
        (yyval.node)->data.func_param.is_borrow = 0;
        (yyval.node)->data.func_param.is_mut = 0;
        if ((yyvsp[-2].node)->data.type_info.is_pointer) (yyvsp[-2].node)->data.type_info.pointer_depth++;
        else { (yyvsp[-2].node)->data.type_info.is_pointer = 1; (yyvsp[-2].node)->data.type_info.pointer_depth = 1; }
    }
#line 2075 "parser.tab.c"
    break;

  case 66: /* param: BORROW type IDENTIFIER  */
#line 317 "parser.y"
                             {
        (yyval.node) = ast_create_node(NODE_FUNC_PARAM, yylineno, yycolumn);
        (yyval.node)->data.func_param.type = (yyvsp[-1].node);
        (yyval.node)->data.func_param.name = (yyvsp[0].string_val);
        (yyval.node)->data.func_param.is_borrow = 1;
        (yyval.node)->data.func_param.is_mut = 0;
    }
#line 2087 "parser.tab.c"
    break;

  case 67: /* param: BORROW IDENTIFIER  */
#line 324 "parser.y"
                        {
        (yyval.node) = ast_create_node(NODE_FUNC_PARAM, yylineno, yycolumn);
        (yyval.node)->data.func_param.type = NULL;
        (yyval.node)->data.func_param.name = (yyvsp[0].string_val);
        (yyval.node)->data.func_param.is_borrow = 1;
        (yyval.node)->data.func_param.is_mut = 0;
    }
#line 2099 "parser.tab.c"
    break;

  case 68: /* param: MUT type IDENTIFIER  */
#line 331 "parser.y"
                          {
        (yyval.node) = ast_create_node(NODE_FUNC_PARAM, yylineno, yycolumn);
        (yyval.node)->data.func_param.type = (yyvsp[-1].node);
        (yyval.node)->data.func_param.name = (yyvsp[0].string_val);
        (yyval.node)->data.func_param.is_borrow = 0;
        (yyval.node)->data.func_param.is_mut = 1;
    }
#line 2111 "parser.tab.c"
    break;

  case 69: /* block: LBRACE RBRACE  */
#line 341 "parser.y"
                    {
        (yyval.node) = ast_create_node(NODE_BLOCK, yylineno, yycolumn);
        (yyval.node)->data.block.stmts = NULL;
        (yyval.node)->data.block.stmt_count = 0;
    }
#line 2121 "parser.tab.c"
    break;

  case 70: /* block: LBRACE stmt_list RBRACE  */
#line 346 "parser.y"
                              {
        (yyval.node) = (yyvsp[-1].node);
    }
#line 2129 "parser.tab.c"
    break;

  case 71: /* stmt_list: stmt  */
#line 352 "parser.y"
           {
        (yyval.node) = ast_create_node(NODE_BLOCK, yylineno, yycolumn);
        (yyval.node)->data.block.stmts = malloc(sizeof(AstNode*));
        (yyval.node)->data.block.stmts[0] = (yyvsp[0].node);
        (yyval.node)->data.block.stmt_count = 1;
    }
#line 2140 "parser.tab.c"
    break;

  case 72: /* stmt_list: stmt_list stmt  */
#line 358 "parser.y"
                     {
        AstNode *blk = (yyvsp[-1].node);
        blk->data.block.stmts = realloc(blk->data.block.stmts,
            sizeof(AstNode*) * (blk->data.block.stmt_count + 1));
        blk->data.block.stmts[blk->data.block.stmt_count++] = (yyvsp[0].node);
        (yyval.node) = blk;
    }
#line 2152 "parser.tab.c"
    break;

  case 73: /* stmt: expr opt_semicolon  */
#line 368 "parser.y"
                         { (yyval.node) = (yyvsp[-1].node); }
#line 2158 "parser.tab.c"
    break;

  case 74: /* stmt: return_stmt  */
#line 369 "parser.y"
                  { (yyval.node) = (yyvsp[0].node); }
#line 2164 "parser.tab.c"
    break;

  case 75: /* stmt: if_stmt  */
#line 370 "parser.y"
              { (yyval.node) = (yyvsp[0].node); }
#line 2170 "parser.tab.c"
    break;

  case 76: /* stmt: switch_stmt  */
#line 371 "parser.y"
                  { (yyval.node) = (yyvsp[0].node); }
#line 2176 "parser.tab.c"
    break;

  case 77: /* stmt: match_stmt  */
#line 372 "parser.y"
                 { (yyval.node) = (yyvsp[0].node); }
#line 2182 "parser.tab.c"
    break;

  case 78: /* stmt: for_stmt  */
#line 373 "parser.y"
               { (yyval.node) = (yyvsp[0].node); }
#line 2188 "parser.tab.c"
    break;

  case 79: /* stmt: using_stmt  */
#line 374 "parser.y"
                 { (yyval.node) = (yyvsp[0].node); }
#line 2194 "parser.tab.c"
    break;

  case 80: /* stmt: unsafe_stmt  */
#line 375 "parser.y"
                  { (yyval.node) = (yyvsp[0].node); }
#line 2200 "parser.tab.c"
    break;

  case 81: /* stmt: decl_stmt  */
#line 376 "parser.y"
                { (yyval.node) = (yyvsp[0].node); }
#line 2206 "parser.tab.c"
    break;

  case 84: /* decl_stmt: type IDENTIFIER ASSIGN expr SEMICOLON  */
#line 385 "parser.y"
                                            {
        (yyval.node) = ast_create_node(NODE_BINARY, yylineno, yycolumn);
        (yyval.node)->data.binary.op_str = strdup("=");
        AstNode *lhs = ast_create_node(NODE_IDENTIFIER, yylineno, yycolumn);
        lhs->data.identifier = (yyvsp[-3].string_val);
        (yyval.node)->data.binary.lhs = lhs;
        (yyval.node)->data.binary.rhs = (yyvsp[-1].node);
    }
#line 2219 "parser.tab.c"
    break;

  case 85: /* decl_stmt: type IDENTIFIER ASSIGN LBRACE opt_arg_list RBRACE SEMICOLON  */
#line 393 "parser.y"
                                                                  {
        (yyval.node) = ast_create_node(NODE_BINARY, yylineno, yycolumn);
        (yyval.node)->data.binary.op_str = strdup("=");
        AstNode *lhs = ast_create_node(NODE_IDENTIFIER, yylineno, yycolumn);
        lhs->data.identifier = (yyvsp[-5].string_val);
        (yyval.node)->data.binary.lhs = lhs;
        AstNode *init = ast_create_node(NODE_STRUCT_INIT, yylineno, yycolumn);
        if ((yyvsp[-2].node)) {
            init->data.struct_init.args = (yyvsp[-2].node)->data.block.stmts;
            init->data.struct_init.arg_count = (yyvsp[-2].node)->data.block.stmt_count;
            free((yyvsp[-2].node));
        } else {
            init->data.struct_init.args = NULL;
            init->data.struct_init.arg_count = 0;
        }
        (yyval.node)->data.binary.rhs = init;
    }
#line 2241 "parser.tab.c"
    break;

  case 86: /* decl_stmt: type STAR IDENTIFIER ASSIGN expr SEMICOLON  */
#line 410 "parser.y"
                                                 {
        (yyval.node) = ast_create_node(NODE_BINARY, yylineno, yycolumn);
        (yyval.node)->data.binary.op_str = strdup("=");
        AstNode *lhs = ast_create_node(NODE_IDENTIFIER, yylineno, yycolumn);
        lhs->data.identifier = (yyvsp[-3].string_val);
        (yyval.node)->data.binary.lhs = lhs;
        (yyval.node)->data.binary.rhs = (yyvsp[-1].node);
        if ((yyvsp[-5].node)->data.type_info.is_pointer) (yyvsp[-5].node)->data.type_info.pointer_depth++;
        else { (yyvsp[-5].node)->data.type_info.is_pointer = 1; (yyvsp[-5].node)->data.type_info.pointer_depth = 1; }
    }
#line 2256 "parser.tab.c"
    break;

  case 87: /* decl_stmt: MUT type IDENTIFIER ASSIGN expr SEMICOLON  */
#line 420 "parser.y"
                                                {
        (yyval.node) = ast_create_node(NODE_BINARY, yylineno, yycolumn);
        (yyval.node)->data.binary.op_str = strdup("=");
        AstNode *lhs = ast_create_node(NODE_IDENTIFIER, yylineno, yycolumn);
        lhs->data.identifier = (yyvsp[-3].string_val);
        (yyval.node)->data.binary.lhs = lhs;
        (yyval.node)->data.binary.rhs = (yyvsp[-1].node);
    }
#line 2269 "parser.tab.c"
    break;

  case 88: /* decl_stmt: MUT type IDENTIFIER ASSIGN LBRACE opt_arg_list RBRACE SEMICOLON  */
#line 428 "parser.y"
                                                                      {
        (yyval.node) = ast_create_node(NODE_BINARY, yylineno, yycolumn);
        (yyval.node)->data.binary.op_str = strdup("=");
        AstNode *lhs = ast_create_node(NODE_IDENTIFIER, yylineno, yycolumn);
        lhs->data.identifier = (yyvsp[-5].string_val);
        (yyval.node)->data.binary.lhs = lhs;
        AstNode *init = ast_create_node(NODE_STRUCT_INIT, yylineno, yycolumn);
        if ((yyvsp[-2].node)) {
            init->data.struct_init.args = (yyvsp[-2].node)->data.block.stmts;
            init->data.struct_init.arg_count = (yyvsp[-2].node)->data.block.stmt_count;
            free((yyvsp[-2].node));
        } else {
            init->data.struct_init.args = NULL;
            init->data.struct_init.arg_count = 0;
        }
        (yyval.node)->data.binary.rhs = init;
    }
#line 2291 "parser.tab.c"
    break;

  case 89: /* decl_stmt: BORROW IDENTIFIER ASSIGN expr SEMICOLON  */
#line 445 "parser.y"
                                              {
        (yyval.node) = ast_create_node(NODE_BINARY, yylineno, yycolumn);
        (yyval.node)->data.binary.op_str = strdup("=");
        AstNode *lhs = ast_create_node(NODE_IDENTIFIER, yylineno, yycolumn);
        lhs->data.identifier = (yyvsp[-3].string_val);
        (yyval.node)->data.binary.lhs = lhs;
        (yyval.node)->data.binary.rhs = (yyvsp[-1].node);
    }
#line 2304 "parser.tab.c"
    break;

  case 90: /* decl_stmt: BORROW MUT IDENTIFIER ASSIGN expr SEMICOLON  */
#line 453 "parser.y"
                                                  {
        (yyval.node) = ast_create_node(NODE_BINARY, yylineno, yycolumn);
        (yyval.node)->data.binary.op_str = strdup("=");
        AstNode *lhs = ast_create_node(NODE_IDENTIFIER, yylineno, yycolumn);
        lhs->data.identifier = (yyvsp[-3].string_val);
        (yyval.node)->data.binary.lhs = lhs;
        (yyval.node)->data.binary.rhs = (yyvsp[-1].node);
    }
#line 2317 "parser.tab.c"
    break;

  case 91: /* return_stmt: RETURN SEMICOLON  */
#line 464 "parser.y"
                       {
        (yyval.node) = ast_create_node(NODE_RETURN, yylineno, yycolumn);
        (yyval.node)->data.unary.operand = NULL;
    }
#line 2326 "parser.tab.c"
    break;

  case 92: /* return_stmt: RETURN expr SEMICOLON  */
#line 468 "parser.y"
                            {
        (yyval.node) = ast_create_node(NODE_RETURN, yylineno, yycolumn);
        (yyval.node)->data.unary.operand = (yyvsp[-1].node);
    }
#line 2335 "parser.tab.c"
    break;

  case 93: /* if_stmt: IF expr block  */
#line 475 "parser.y"
                    {
        (yyval.node) = ast_create_node(NODE_IF, yylineno, yycolumn);
        (yyval.node)->data.if_stmt.expr = (yyvsp[-1].node);
        (yyval.node)->data.if_stmt.then_block = (yyvsp[0].node);
        (yyval.node)->data.if_stmt.else_block = NULL;
    }
#line 2346 "parser.tab.c"
    break;

  case 94: /* if_stmt: IF expr block ELSE if_stmt  */
#line 481 "parser.y"
                                 {
        (yyval.node) = ast_create_node(NODE_IF, yylineno, yycolumn);
        (yyval.node)->data.if_stmt.expr = (yyvsp[-3].node);
        (yyval.node)->data.if_stmt.then_block = (yyvsp[-2].node);
        (yyval.node)->data.if_stmt.else_block = (yyvsp[0].node);
    }
#line 2357 "parser.tab.c"
    break;

  case 95: /* if_stmt: IF expr block ELSE block  */
#line 487 "parser.y"
                               {
        (yyval.node) = ast_create_node(NODE_IF, yylineno, yycolumn);
        (yyval.node)->data.if_stmt.expr = (yyvsp[-3].node);
        (yyval.node)->data.if_stmt.then_block = (yyvsp[-2].node);
        (yyval.node)->data.if_stmt.else_block = (yyvsp[0].node);
    }
#line 2368 "parser.tab.c"
    break;

  case 96: /* switch_stmt: SWITCH LPAREN expr RPAREN LBRACE case_list RBRACE  */
#line 496 "parser.y"
                                                        {
        (yyval.node) = ast_create_node(NODE_SWITCH, yylineno, yycolumn);
        (yyval.node)->data.switch_stmt.expr = (yyvsp[-4].node);
        if ((yyvsp[-1].node)) {
            (yyval.node)->data.switch_stmt.cases = (yyvsp[-1].node)->data.block.stmts;
            (yyval.node)->data.switch_stmt.case_count = (yyvsp[-1].node)->data.block.stmt_count;
            free((yyvsp[-1].node));
        } else {
            (yyval.node)->data.switch_stmt.cases = NULL;
            (yyval.node)->data.switch_stmt.case_count = 0;
        }
    }
#line 2385 "parser.tab.c"
    break;

  case 97: /* case_list: case  */
#line 511 "parser.y"
           {
        (yyval.node) = ast_create_node(NODE_BLOCK, yylineno, yycolumn);
        (yyval.node)->data.block.stmts = malloc(sizeof(AstNode*));
        (yyval.node)->data.block.stmts[0] = (yyvsp[0].node);
        (yyval.node)->data.block.stmt_count = 1;
    }
#line 2396 "parser.tab.c"
    break;

  case 98: /* case_list: case_list case  */
#line 517 "parser.y"
                     {
        AstNode *blk = (yyvsp[-1].node);
        blk->data.block.stmts = realloc(blk->data.block.stmts,
            sizeof(AstNode*) * (blk->data.block.stmt_count + 1));
        blk->data.block.stmts[blk->data.block.stmt_count++] = (yyvsp[0].node);
        (yyval.node) = blk;
    }
#line 2408 "parser.tab.c"
    break;

  case 99: /* case: CASE expr block  */
#line 527 "parser.y"
                      {
        (yyval.node) = ast_create_node(NODE_CASE, yylineno, yycolumn);
        (yyval.node)->data.case_branch.value = (yyvsp[-1].node);
        (yyval.node)->data.case_branch.body = (yyvsp[0].node);
    }
#line 2418 "parser.tab.c"
    break;

  case 100: /* case: CASE STAR block  */
#line 532 "parser.y"
                      {
        (yyval.node) = ast_create_node(NODE_CASE, yylineno, yycolumn);
        (yyval.node)->data.case_branch.value = NULL;
        (yyval.node)->data.case_branch.body = (yyvsp[0].node);
    }
#line 2428 "parser.tab.c"
    break;

  case 101: /* match_stmt: MATCH LPAREN expr RPAREN LBRACE match_case_list RBRACE  */
#line 540 "parser.y"
                                                             {
        (yyval.node) = ast_create_node(NODE_MATCH, yylineno, yycolumn);
        (yyval.node)->data.match_stmt.expr = (yyvsp[-4].node);
        if ((yyvsp[-1].node)) {
            (yyval.node)->data.match_stmt.cases = (yyvsp[-1].node)->data.block.stmts;
            (yyval.node)->data.match_stmt.case_count = (yyvsp[-1].node)->data.block.stmt_count;
            free((yyvsp[-1].node));
        } else {
            (yyval.node)->data.match_stmt.cases = NULL;
            (yyval.node)->data.match_stmt.case_count = 0;
        }
    }
#line 2445 "parser.tab.c"
    break;

  case 102: /* match_case_list: match_case  */
#line 555 "parser.y"
                 {
        (yyval.node) = ast_create_node(NODE_BLOCK, yylineno, yycolumn);
        (yyval.node)->data.block.stmts = malloc(sizeof(AstNode*));
        (yyval.node)->data.block.stmts[0] = (yyvsp[0].node);
        (yyval.node)->data.block.stmt_count = 1;
    }
#line 2456 "parser.tab.c"
    break;

  case 103: /* match_case_list: match_case_list match_case  */
#line 561 "parser.y"
                                 {
        AstNode *blk = (yyvsp[-1].node);
        blk->data.block.stmts = realloc(blk->data.block.stmts,
            sizeof(AstNode*) * (blk->data.block.stmt_count + 1));
        blk->data.block.stmts[blk->data.block.stmt_count++] = (yyvsp[0].node);
        (yyval.node) = blk;
    }
#line 2468 "parser.tab.c"
    break;

  case 104: /* match_case: CASE IDENTIFIER IN expr block  */
#line 571 "parser.y"
                                    {
        (yyval.node) = ast_create_node(NODE_MATCH_CASE, yylineno, yycolumn);
        (yyval.node)->data.case_branch.value = (yyvsp[-1].node);
        (yyval.node)->data.case_branch.body = (yyvsp[0].node);
    }
#line 2478 "parser.tab.c"
    break;

  case 105: /* match_case: CASE expr block  */
#line 576 "parser.y"
                      {
        (yyval.node) = ast_create_node(NODE_MATCH_CASE, yylineno, yycolumn);
        (yyval.node)->data.case_branch.value = (yyvsp[-1].node);
        (yyval.node)->data.case_branch.body = (yyvsp[0].node);
    }
#line 2488 "parser.tab.c"
    break;

  case 106: /* match_case: CASE STAR block  */
#line 581 "parser.y"
                      {
        (yyval.node) = ast_create_node(NODE_MATCH_CASE, yylineno, yycolumn);
        (yyval.node)->data.case_branch.value = NULL;
        (yyval.node)->data.case_branch.body = (yyvsp[0].node);
    }
#line 2498 "parser.tab.c"
    break;

  case 107: /* for_stmt: FOR IDENTIFIER IN expr block  */
#line 589 "parser.y"
                                   {
        (yyval.node) = ast_create_node(NODE_FOR, yylineno, yycolumn);
        (yyval.node)->data.for_stmt.var = (yyvsp[-3].string_val);
        (yyval.node)->data.for_stmt.range = (yyvsp[-1].node);
        (yyval.node)->data.for_stmt.body = (yyvsp[0].node);
    }
#line 2509 "parser.tab.c"
    break;

  case 108: /* using_stmt: USING LPAREN expr RPAREN block  */
#line 598 "parser.y"
                                     {
        (yyval.node) = ast_create_node(NODE_USING, yylineno, yycolumn);
        (yyval.node)->data.using_stmt.resource = (yyvsp[-2].node);
        (yyval.node)->data.using_stmt.body = (yyvsp[0].node);
    }
#line 2519 "parser.tab.c"
    break;

  case 109: /* unsafe_stmt: UNSAFE block  */
#line 606 "parser.y"
                   {
        (yyval.node) = ast_create_node(NODE_UNSAFE, yylineno, yycolumn);
        (yyval.node)->data.unsafe_stmt.body = (yyvsp[0].node);
    }
#line 2528 "parser.tab.c"
    break;

  case 110: /* type: INT  */
#line 613 "parser.y"
          { (yyval.node) = ast_create_node(NODE_TYPE, yylineno, yycolumn); (yyval.node)->data.type_info.base = TYPE_INT; }
#line 2534 "parser.tab.c"
    break;

  case 111: /* type: VOID  */
#line 614 "parser.y"
           { (yyval.node) = ast_create_node(NODE_TYPE, yylineno, yycolumn); (yyval.node)->data.type_info.base = TYPE_VOID; }
#line 2540 "parser.tab.c"
    break;

  case 112: /* type: STRING  */
#line 615 "parser.y"
             { (yyval.node) = ast_create_node(NODE_TYPE, yylineno, yycolumn); (yyval.node)->data.type_info.base = TYPE_STRING; }
#line 2546 "parser.tab.c"
    break;

  case 113: /* type: LOCK  */
#line 616 "parser.y"
           { (yyval.node) = ast_create_node(NODE_TYPE, yylineno, yycolumn); (yyval.node)->data.type_info.base = TYPE_LOCK; }
#line 2552 "parser.tab.c"
    break;

  case 114: /* type: IDENTIFIER  */
#line 617 "parser.y"
                 { (yyval.node) = ast_create_node(NODE_TYPE, yylineno, yycolumn); (yyval.node)->data.type_info.base = TYPE_CUSTOM; (yyval.node)->data.type_info.custom_name = (yyvsp[0].string_val); }
#line 2558 "parser.tab.c"
    break;

  case 115: /* arg_list: expr  */
#line 621 "parser.y"
           {
        (yyval.node) = ast_create_node(NODE_BLOCK, yylineno, yycolumn);
        (yyval.node)->data.block.stmts = malloc(sizeof(AstNode*));
        (yyval.node)->data.block.stmts[0] = (yyvsp[0].node);
        (yyval.node)->data.block.stmt_count = 1;
    }
#line 2569 "parser.tab.c"
    break;

  case 116: /* arg_list: arg_list COMMA expr  */
#line 627 "parser.y"
                          {
        AstNode *list = (yyvsp[-2].node);
        list->data.block.stmts = realloc(list->data.block.stmts,
            sizeof(AstNode*) * (list->data.block.stmt_count + 1));
        list->data.block.stmts[list->data.block.stmt_count++] = (yyvsp[0].node);
        (yyval.node) = list;
    }
#line 2581 "parser.tab.c"
    break;

  case 117: /* opt_arg_list: %empty  */
#line 637 "parser.y"
                  { (yyval.node) = NULL; }
#line 2587 "parser.tab.c"
    break;

  case 118: /* opt_arg_list: arg_list  */
#line 638 "parser.y"
               { (yyval.node) = (yyvsp[0].node); }
#line 2593 "parser.tab.c"
    break;

  case 119: /* expr: postfix_expr  */
#line 642 "parser.y"
                   { (yyval.node) = (yyvsp[0].node); }
#line 2599 "parser.tab.c"
    break;

  case 120: /* expr: expr PLUS expr  */
#line 643 "parser.y"
                     { (yyval.node) = ast_create_node(NODE_BINARY, yylineno, yycolumn); (yyval.node)->data.binary.op_str = strdup("+"); (yyval.node)->data.binary.lhs = (yyvsp[-2].node); (yyval.node)->data.binary.rhs = (yyvsp[0].node); }
#line 2605 "parser.tab.c"
    break;

  case 121: /* expr: expr MINUS expr  */
#line 644 "parser.y"
                      { (yyval.node) = ast_create_node(NODE_BINARY, yylineno, yycolumn); (yyval.node)->data.binary.op_str = strdup("-"); (yyval.node)->data.binary.lhs = (yyvsp[-2].node); (yyval.node)->data.binary.rhs = (yyvsp[0].node); }
#line 2611 "parser.tab.c"
    break;

  case 122: /* expr: expr STAR expr  */
#line 645 "parser.y"
                     { (yyval.node) = ast_create_node(NODE_BINARY, yylineno, yycolumn); (yyval.node)->data.binary.op_str = strdup("*"); (yyval.node)->data.binary.lhs = (yyvsp[-2].node); (yyval.node)->data.binary.rhs = (yyvsp[0].node); }
#line 2617 "parser.tab.c"
    break;

  case 123: /* expr: expr SLASH expr  */
#line 646 "parser.y"
                      { (yyval.node) = ast_create_node(NODE_BINARY, yylineno, yycolumn); (yyval.node)->data.binary.op_str = strdup("/"); (yyval.node)->data.binary.lhs = (yyvsp[-2].node); (yyval.node)->data.binary.rhs = (yyvsp[0].node); }
#line 2623 "parser.tab.c"
    break;

  case 124: /* expr: expr PERCENT expr  */
#line 647 "parser.y"
                        { (yyval.node) = ast_create_node(NODE_BINARY, yylineno, yycolumn); (yyval.node)->data.binary.op_str = strdup("%"); (yyval.node)->data.binary.lhs = (yyvsp[-2].node); (yyval.node)->data.binary.rhs = (yyvsp[0].node); }
#line 2629 "parser.tab.c"
    break;

  case 125: /* expr: expr EQ expr  */
#line 648 "parser.y"
                   { (yyval.node) = ast_create_node(NODE_BINARY, yylineno, yycolumn); (yyval.node)->data.binary.op_str = strdup("=="); (yyval.node)->data.binary.lhs = (yyvsp[-2].node); (yyval.node)->data.binary.rhs = (yyvsp[0].node); }
#line 2635 "parser.tab.c"
    break;

  case 126: /* expr: expr NEQ expr  */
#line 649 "parser.y"
                    { (yyval.node) = ast_create_node(NODE_BINARY, yylineno, yycolumn); (yyval.node)->data.binary.op_str = strdup("!="); (yyval.node)->data.binary.lhs = (yyvsp[-2].node); (yyval.node)->data.binary.rhs = (yyvsp[0].node); }
#line 2641 "parser.tab.c"
    break;

  case 127: /* expr: expr LT expr  */
#line 650 "parser.y"
                   { (yyval.node) = ast_create_node(NODE_BINARY, yylineno, yycolumn); (yyval.node)->data.binary.op_str = strdup("<"); (yyval.node)->data.binary.lhs = (yyvsp[-2].node); (yyval.node)->data.binary.rhs = (yyvsp[0].node); }
#line 2647 "parser.tab.c"
    break;

  case 128: /* expr: expr GT expr  */
#line 651 "parser.y"
                   { (yyval.node) = ast_create_node(NODE_BINARY, yylineno, yycolumn); (yyval.node)->data.binary.op_str = strdup(">"); (yyval.node)->data.binary.lhs = (yyvsp[-2].node); (yyval.node)->data.binary.rhs = (yyvsp[0].node); }
#line 2653 "parser.tab.c"
    break;

  case 129: /* expr: expr LTE expr  */
#line 652 "parser.y"
                    { (yyval.node) = ast_create_node(NODE_BINARY, yylineno, yycolumn); (yyval.node)->data.binary.op_str = strdup("<="); (yyval.node)->data.binary.lhs = (yyvsp[-2].node); (yyval.node)->data.binary.rhs = (yyvsp[0].node); }
#line 2659 "parser.tab.c"
    break;

  case 130: /* expr: expr GTE expr  */
#line 653 "parser.y"
                    { (yyval.node) = ast_create_node(NODE_BINARY, yylineno, yycolumn); (yyval.node)->data.binary.op_str = strdup(">="); (yyval.node)->data.binary.lhs = (yyvsp[-2].node); (yyval.node)->data.binary.rhs = (yyvsp[0].node); }
#line 2665 "parser.tab.c"
    break;

  case 131: /* expr: expr AND expr  */
#line 654 "parser.y"
                    { (yyval.node) = ast_create_node(NODE_BINARY, yylineno, yycolumn); (yyval.node)->data.binary.op_str = strdup("&&"); (yyval.node)->data.binary.lhs = (yyvsp[-2].node); (yyval.node)->data.binary.rhs = (yyvsp[0].node); }
#line 2671 "parser.tab.c"
    break;

  case 132: /* expr: expr OR expr  */
#line 655 "parser.y"
                   { (yyval.node) = ast_create_node(NODE_BINARY, yylineno, yycolumn); (yyval.node)->data.binary.op_str = strdup("||"); (yyval.node)->data.binary.lhs = (yyvsp[-2].node); (yyval.node)->data.binary.rhs = (yyvsp[0].node); }
#line 2677 "parser.tab.c"
    break;

  case 133: /* expr: expr RANGE expr  */
#line 656 "parser.y"
                      {
        (yyval.node) = ast_create_node(NODE_RANGE, yylineno, yycolumn);
        (yyval.node)->data.range.start = (yyvsp[-2].node);
        (yyval.node)->data.range.end = (yyvsp[0].node);
    }
#line 2687 "parser.tab.c"
    break;

  case 134: /* expr: expr ASSIGN expr  */
#line 661 "parser.y"
                       {
        (yyval.node) = ast_create_node(NODE_BINARY, yylineno, yycolumn);
        (yyval.node)->data.binary.op_str = strdup("=");
        (yyval.node)->data.binary.lhs = (yyvsp[-2].node);
        (yyval.node)->data.binary.rhs = (yyvsp[0].node);
    }
#line 2698 "parser.tab.c"
    break;

  case 135: /* expr: expr PLUS_ASSIGN expr  */
#line 667 "parser.y"
                            {
        (yyval.node) = ast_create_node(NODE_BINARY, yylineno, yycolumn);
        (yyval.node)->data.binary.op_str = strdup("+=");
        (yyval.node)->data.binary.lhs = (yyvsp[-2].node);
        (yyval.node)->data.binary.rhs = (yyvsp[0].node);
    }
#line 2709 "parser.tab.c"
    break;

  case 136: /* expr: expr MINUS_ASSIGN expr  */
#line 673 "parser.y"
                             {
        (yyval.node) = ast_create_node(NODE_BINARY, yylineno, yycolumn);
        (yyval.node)->data.binary.op_str = strdup("-=");
        (yyval.node)->data.binary.lhs = (yyvsp[-2].node);
        (yyval.node)->data.binary.rhs = (yyvsp[0].node);
    }
#line 2720 "parser.tab.c"
    break;

  case 137: /* expr: expr STAR_ASSIGN expr  */
#line 679 "parser.y"
                            {
        (yyval.node) = ast_create_node(NODE_BINARY, yylineno, yycolumn);
        (yyval.node)->data.binary.op_str = strdup("*=");
        (yyval.node)->data.binary.lhs = (yyvsp[-2].node);
        (yyval.node)->data.binary.rhs = (yyvsp[0].node);
    }
#line 2731 "parser.tab.c"
    break;

  case 138: /* expr: expr SLASH_ASSIGN expr  */
#line 685 "parser.y"
                             {
        (yyval.node) = ast_create_node(NODE_BINARY, yylineno, yycolumn);
        (yyval.node)->data.binary.op_str = strdup("/=");
        (yyval.node)->data.binary.lhs = (yyvsp[-2].node);
        (yyval.node)->data.binary.rhs = (yyvsp[0].node);
    }
#line 2742 "parser.tab.c"
    break;

  case 139: /* expr: MINUS expr  */
#line 691 "parser.y"
                              {
        (yyval.node) = ast_create_node(NODE_UNARY, yylineno, yycolumn);
        (yyval.node)->data.unary.op = strdup("-");
        (yyval.node)->data.unary.operand = (yyvsp[0].node);
    }
#line 2752 "parser.tab.c"
    break;

  case 140: /* expr: NOT expr  */
#line 696 "parser.y"
                         {
        (yyval.node) = ast_create_node(NODE_UNARY, yylineno, yycolumn);
        (yyval.node)->data.unary.op = strdup("!");
        (yyval.node)->data.unary.operand = (yyvsp[0].node);
    }
#line 2762 "parser.tab.c"
    break;

  case 141: /* expr: AMP expr  */
#line 701 "parser.y"
                           {
        (yyval.node) = ast_create_node(NODE_UNARY, yylineno, yycolumn);
        (yyval.node)->data.unary.op = strdup("&");
        (yyval.node)->data.unary.operand = (yyvsp[0].node);
    }
#line 2772 "parser.tab.c"
    break;

  case 142: /* expr: THREAD RUN LPAREN expr RPAREN  */
#line 706 "parser.y"
                                    {
        (yyval.node) = ast_create_node(NODE_THREAD_RUN, yylineno, yycolumn);
        (yyval.node)->data.thread_run.call = (yyvsp[-1].node);
    }
#line 2781 "parser.tab.c"
    break;

  case 143: /* expr: THREAD DOT RUN LPAREN expr RPAREN  */
#line 710 "parser.y"
                                        {
        (yyval.node) = ast_create_node(NODE_THREAD_RUN, yylineno, yycolumn);
        (yyval.node)->data.thread_run.call = (yyvsp[-1].node);
    }
#line 2790 "parser.tab.c"
    break;

  case 144: /* expr: MEM DOT DROP LPAREN expr RPAREN  */
#line 714 "parser.y"
                                      {
        (yyval.node) = ast_create_node(NODE_DROP, yylineno, yycolumn);
        (yyval.node)->data.drop_expr.expr = (yyvsp[-1].node);
    }
#line 2799 "parser.tab.c"
    break;

  case 145: /* expr: MEM DOT SIZEOF LPAREN type RPAREN  */
#line 718 "parser.y"
                                        {
        (yyval.node) = ast_create_node(NODE_SIZEOF, yylineno, yycolumn);
        (yyval.node)->data.sizeof_expr.type = (yyvsp[-1].node);
        (yyval.node)->data.sizeof_expr.size = NULL;
    }
#line 2809 "parser.tab.c"
    break;

  case 146: /* expr: MEM DOT ALLOC LPAREN expr RPAREN  */
#line 723 "parser.y"
                                       {
        (yyval.node) = ast_create_node(NODE_CALL, yylineno, yycolumn);
        (yyval.node)->data.call.name = strdup("mem.alloc");
        (yyval.node)->data.call.args = malloc(sizeof(AstNode*));
        (yyval.node)->data.call.args[0] = (yyvsp[-1].node);
        (yyval.node)->data.call.arg_count = 1;
    }
#line 2821 "parser.tab.c"
    break;

  case 147: /* expr: FREE LPAREN expr RPAREN  */
#line 730 "parser.y"
                              {
        (yyval.node) = ast_create_node(NODE_FREE, yylineno, yycolumn);
        (yyval.node)->data.free_expr.expr = (yyvsp[-1].node);
    }
#line 2830 "parser.tab.c"
    break;

  case 148: /* postfix_expr: primary  */
#line 737 "parser.y"
              { (yyval.node) = (yyvsp[0].node); }
#line 2836 "parser.tab.c"
    break;

  case 149: /* postfix_expr: postfix_expr DOT IDENTIFIER  */
#line 738 "parser.y"
                                  {
        (yyval.node) = ast_create_node(NODE_MEMBER_ACCESS, yylineno, yycolumn);
        (yyval.node)->data.member_access.object = (yyvsp[-2].node);
        (yyval.node)->data.member_access.member = (yyvsp[0].string_val);
    }
#line 2846 "parser.tab.c"
    break;

  case 150: /* postfix_expr: postfix_expr LPAREN opt_arg_list RPAREN  */
#line 743 "parser.y"
                                              {
        (yyval.node) = ast_create_node(NODE_CALL, yylineno, yycolumn);
        if ((yyvsp[-3].node)->type == NODE_IDENTIFIER) {
            (yyval.node)->data.call.name = (yyvsp[-3].node)->data.identifier;
            (yyvsp[-3].node)->data.identifier = NULL;
            ast_free((yyvsp[-3].node));
        } else {
            (yyval.node)->data.call.name = NULL;
        }
        if ((yyvsp[-1].node)) {
            (yyval.node)->data.call.args = (yyvsp[-1].node)->data.block.stmts;
            (yyval.node)->data.call.arg_count = (yyvsp[-1].node)->data.block.stmt_count;
            free((yyvsp[-1].node));
        } else {
            (yyval.node)->data.call.args = NULL;
            (yyval.node)->data.call.arg_count = 0;
        }
    }
#line 2869 "parser.tab.c"
    break;

  case 151: /* postfix_expr: LBRACE opt_arg_list RBRACE  */
#line 761 "parser.y"
                                 {
        (yyval.node) = ast_create_node(NODE_STRUCT_INIT, yylineno, yycolumn);
        if ((yyvsp[-1].node)) {
            (yyval.node)->data.struct_init.args = (yyvsp[-1].node)->data.block.stmts;
            (yyval.node)->data.struct_init.arg_count = (yyvsp[-1].node)->data.block.stmt_count;
            free((yyvsp[-1].node));
        } else {
            (yyval.node)->data.struct_init.args = NULL;
            (yyval.node)->data.struct_init.arg_count = 0;
        }
    }
#line 2885 "parser.tab.c"
    break;

  case 152: /* primary: INT_LIT  */
#line 775 "parser.y"
              {
        (yyval.node) = ast_create_node(NODE_INT_LIT, yylineno, yycolumn);
        (yyval.node)->data.int_value = atol((yyvsp[0].string_val));
        free((yyvsp[0].string_val));
    }
#line 2895 "parser.tab.c"
    break;

  case 153: /* primary: STRING_LIT  */
#line 780 "parser.y"
                 {
        (yyval.node) = ast_create_node(NODE_STRING_LIT, yylineno, yycolumn);
        char *s = (yyvsp[0].string_val);
        s++; s[strlen(s)-1] = '\0';
        (yyval.node)->data.string_value = strdup(s);
        free((yyvsp[0].string_val));
    }
#line 2907 "parser.tab.c"
    break;

  case 154: /* primary: STRING_INTERP  */
#line 787 "parser.y"
                    {
        (yyval.node) = ast_create_node(NODE_STRING_LIT, yylineno, yycolumn);
        char *s = (yyvsp[0].string_val);
        s++; s[strlen(s)-1] = '\0';
        (yyval.node)->data.string_value = strdup(s);
        free((yyvsp[0].string_val));
    }
#line 2919 "parser.tab.c"
    break;

  case 155: /* primary: IDENTIFIER  */
#line 794 "parser.y"
                 {
        (yyval.node) = ast_create_node(NODE_IDENTIFIER, yylineno, yycolumn);
        (yyval.node)->data.identifier = (yyvsp[0].string_val);
    }
#line 2928 "parser.tab.c"
    break;

  case 156: /* primary: SELF  */
#line 798 "parser.y"
           {
        (yyval.node) = ast_create_node(NODE_IDENTIFIER, yylineno, yycolumn);
        (yyval.node)->data.identifier = strdup("self");
    }
#line 2937 "parser.tab.c"
    break;

  case 157: /* primary: SUPER  */
#line 802 "parser.y"
            {
        (yyval.node) = ast_create_node(NODE_IDENTIFIER, yylineno, yycolumn);
        (yyval.node)->data.identifier = strdup("super");
    }
#line 2946 "parser.tab.c"
    break;

  case 158: /* primary: LPAREN expr RPAREN  */
#line 806 "parser.y"
                         { (yyval.node) = (yyvsp[-1].node); }
#line 2952 "parser.tab.c"
    break;

  case 159: /* primary: NEW type LPAREN opt_arg_list RPAREN  */
#line 807 "parser.y"
                                          {
        (yyval.node) = ast_create_node(NODE_NEW, yylineno, yycolumn);
        (yyval.node)->data.new_expr.type = (yyvsp[-3].node);
        if ((yyvsp[-1].node)) {
            (yyval.node)->data.new_expr.args = (yyvsp[-1].node)->data.block.stmts;
            (yyval.node)->data.new_expr.arg_count = (yyvsp[-1].node)->data.block.stmt_count;
            free((yyvsp[-1].node));
        } else {
            (yyval.node)->data.new_expr.args = NULL;
            (yyval.node)->data.new_expr.arg_count = 0;
        }
    }
#line 2969 "parser.tab.c"
    break;

  case 160: /* primary: NEW type  */
#line 819 "parser.y"
               {
        (yyval.node) = ast_create_node(NODE_NEW, yylineno, yycolumn);
        (yyval.node)->data.new_expr.type = (yyvsp[0].node);
        (yyval.node)->data.new_expr.args = NULL;
        (yyval.node)->data.new_expr.arg_count = 0;
    }
#line 2980 "parser.tab.c"
    break;


#line 2984 "parser.tab.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      yyerror (YY_("syntax error"));
    }

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif

  return yyresult;
}

#line 827 "parser.y"


void yyerror(const char *s) {
    fprintf(stderr, "Parse error at line %d, col %d: %s\n", yylineno, yycolumn, s);
}

AstNode *parse_file(const char *filename) {
    yyin = fopen(filename, "r");
    if (!yyin) {
        fprintf(stderr, "Cannot open file: %s\n", filename);
        return NULL;
    }
    yyparse();
    fclose(yyin);
    return program_root;
}

#ifndef yywrap
int yywrap(void) { return 1; }
#endif
