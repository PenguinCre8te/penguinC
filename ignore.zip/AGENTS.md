# AGENTS.md

## About
- This is a programming language named penguinC
- Write it with bison and flex and llvm

## Instructions
- Read ./example.pc for a example for this langauge
- Write a parser for penguinC