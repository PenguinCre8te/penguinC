%{
#include "ast.h"
#include <stdio.h>
#include <string.h>

extern int yylex(void);
extern int yylineno;
extern int yycolumn;
extern FILE *yyin;

void yyerror(const char *s);

AstNode *program_root = NULL;
%}

%union {
    char *string_val;
    long int_val;
    struct AstNode *node;
}

%token <string_val> IDENTIFIER INT_LIT STRING_LIT STRING_INTERP
%token IMPORT LINK AS
%token STRUCT CLASS EXTENDS
%token VOID INT STRING LOCK MUT BORROW NEW SELF SUPER
%token USING SWITCH CASE MATCH UNSAFE FOR IN RETURN IF ELSE
%token THREAD RUN MEM ALLOC SIZEOF DROP FREE
%token PLUS MINUS STAR SLASH PERCENT
%token PLUS_ASSIGN MINUS_ASSIGN STAR_ASSIGN SLASH_ASSIGN
%token EQ NEQ LT GT LTE GTE
%token ASSIGN AND OR NOT
%token AMP PIPE TILDE
%token RANGE ARROW
%token LPAREN RPAREN LBRACE RBRACE LBRACKET RBRACKET
%token SEMICOLON COLON DOT COMMA

%type <node> program top_level_list top_levelstmt
%type <node> import_stmt import_path link_stmt
%type <string_val> any_ident
%type <node> struct_def class_def
%type <node> func_def param_list param
%type <node> block stmt_list stmt
%type <node> return_stmt if_stmt switch_stmt match_stmt for_stmt using_stmt unsafe_stmt
%type <node> decl_stmt
%type <node> expr primary postfix_expr
%type <node> type
%type <node> arg_list opt_arg_list
%type <node> case_list match_case_list case match_case
%type <node> field_list field
%type <node> class_body class_member

%right ASSIGN PLUS_ASSIGN MINUS_ASSIGN STAR_ASSIGN SLASH_ASSIGN
%left OR
%left AND
%left EQ NEQ
%left LT GT LTE GTE
%left PLUS MINUS
%left STAR SLASH PERCENT
%right NOT UMINUS UADDR USTAR
%left DOT ARROW
%right RANGE

%%

program
    : top_level_list { program_root = $1; }
    ;

top_level_list
    : top_level_list top_levelstmt {
        AstNode *prog = $1;
        prog->data.block.stmts = realloc(prog->data.block.stmts,
            sizeof(AstNode*) * (prog->data.block.stmt_count + 1));
        prog->data.block.stmts[prog->data.block.stmt_count++] = $2;
        $$ = prog;
    }
    | top_levelstmt {
        AstNode *prog = ast_create_node(NODE_PROGRAM, yylineno, yycolumn);
        prog->data.block.stmts = malloc(sizeof(AstNode*));
        prog->data.block.stmts[0] = $1;
        prog->data.block.stmt_count = 1;
        $$ = prog;
    }
    ;

top_levelstmt
    : import_stmt { $$ = $1; }
    | link_stmt { $$ = $1; }
    | struct_def { $$ = $1; }
    | class_def { $$ = $1; }
    | func_def { $$ = $1; }
    ;

import_stmt
    : IMPORT STRING_LIT SEMICOLON {
        $$ = ast_create_node(NODE_IMPORT, yylineno, yycolumn);
        char *s = $2;
        s++; s[strlen(s)-1] = '\0';
        $$->data.import.name = strdup(s);
    }
    | IMPORT STRING_LIT AS IDENTIFIER SEMICOLON {
        $$ = ast_create_node(NODE_IMPORT, yylineno, yycolumn);
        char *s = $2;
        s++; s[strlen(s)-1] = '\0';
        $$->data.import.name = strdup(s);
        $$->data.import.alias = $4;
    }
    | IMPORT import_path SEMICOLON {
        $$ = $2;
    }
    ;

import_path
    : any_ident {
        $$ = ast_create_node(NODE_IMPORT, yylineno, yycolumn);
        $$->data.import.name = $1;
    }
    | import_path DOT any_ident {
        $$ = $1;
        size_t len = strlen($$->data.import.name) + 1 + strlen($3) + 1;
        char *buf = malloc(len);
        snprintf(buf, len, "%s.%s", $$->data.import.name, $3);
        free($$->data.import.name);
        free($3);
        $$->data.import.name = buf;
    }
    ;

any_ident
    : IDENTIFIER { $$ = $1; }
    | THREAD { $$ = strdup("thread"); }
    | RUN { $$ = strdup("run"); }
    | MEM { $$ = strdup("mem"); }
    | ALLOC { $$ = strdup("alloc"); }
    | SIZEOF { $$ = strdup("sizeof"); }
    | DROP { $$ = strdup("drop"); }
    | FREE { $$ = strdup("free"); }
    | INT { $$ = strdup("int"); }
    | STRING { $$ = strdup("string"); }
    | VOID { $$ = strdup("void"); }
    | LOCK { $$ = strdup("lock"); }
    | MUT { $$ = strdup("mut"); }
    | BORROW { $$ = strdup("borrow"); }
    | NEW { $$ = strdup("new"); }
    | STRUCT { $$ = strdup("struct"); }
    | CLASS { $$ = strdup("class"); }
    | EXTENDS { $$ = strdup("extends"); }
    | USING { $$ = strdup("using"); }
    | SWITCH { $$ = strdup("switch"); }
    | CASE { $$ = strdup("case"); }
    | MATCH { $$ = strdup("match"); }
    | UNSAFE { $$ = strdup("unsafe"); }
    | FOR { $$ = strdup("for"); }
    | IN { $$ = strdup("in"); }
    | RETURN { $$ = strdup("return"); }
    | IF { $$ = strdup("if"); }
    | ELSE { $$ = strdup("else"); }
    | SELF { $$ = strdup("self"); }
    | SUPER { $$ = strdup("super"); }
    | AS { $$ = strdup("as"); }
    ;

link_stmt
    : LINK STRING_LIT SEMICOLON {
        $$ = ast_create_node(NODE_LINK, yylineno, yycolumn);
        char *s = $2;
        s++; s[strlen(s)-1] = '\0';
        $$->data.link.path = strdup(s);
    }
    ;

struct_def
    : STRUCT IDENTIFIER LBRACE field_list RBRACE SEMICOLON {
        $$ = ast_create_node(NODE_STRUCT_DEF, yylineno, yycolumn);
        $$->data.struct_def.name = $2;
        $$->data.struct_def.fields = $4->data.block.stmts;
        $$->data.struct_def.field_count = $4->data.block.stmt_count;
        free($4);
    }
    | STRUCT IDENTIFIER LBRACE RBRACE SEMICOLON {
        $$ = ast_create_node(NODE_STRUCT_DEF, yylineno, yycolumn);
        $$->data.struct_def.name = $2;
        $$->data.struct_def.fields = NULL;
        $$->data.struct_def.field_count = 0;
    }
    ;

field_list
    : field {
        $$ = ast_create_node(NODE_BLOCK, yylineno, yycolumn);
        $$->data.block.stmts = malloc(sizeof(AstNode*));
        $$->data.block.stmts[0] = $1;
        $$->data.block.stmt_count = 1;
    }
    | field_list field {
        AstNode *blk = $1;
        blk->data.block.stmts = realloc(blk->data.block.stmts,
            sizeof(AstNode*) * (blk->data.block.stmt_count + 1));
        blk->data.block.stmts[blk->data.block.stmt_count++] = $2;
        $$ = blk;
    }
    ;

field
    : type IDENTIFIER SEMICOLON {
        $$ = ast_create_node(NODE_FUNC_PARAM, yylineno, yycolumn);
        $$->data.func_param.type = $1;
        $$->data.func_param.name = $2;
        $$->data.func_param.is_borrow = 0;
        $$->data.func_param.is_mut = 0;
    }
    ;

class_def
    : CLASS IDENTIFIER LBRACE class_body RBRACE {
        $$ = ast_create_node(NODE_CLASS_DEF, yylineno, yycolumn);
        $$->data.class_def.name = $2;
        $$->data.class_def.parent = NULL;
        $$->data.class_def.members = NULL;
        $$->data.class_def.member_count = 0;
    }
    | CLASS IDENTIFIER EXTENDS IDENTIFIER LBRACE class_body RBRACE {
        $$ = ast_create_node(NODE_CLASS_DEF, yylineno, yycolumn);
        $$->data.class_def.name = $2;
        $$->data.class_def.parent = $4;
        $$->data.class_def.members = NULL;
        $$->data.class_def.member_count = 0;
    }
    ;

class_body
    : class_body class_member {
        $$ = $1;
    }
    | {
        $$ = ast_create_node(NODE_BLOCK, yylineno, yycolumn);
        $$->data.block.stmts = NULL;
        $$->data.block.stmt_count = 0;
    }
    ;

class_member
    : type IDENTIFIER SEMICOLON
    | func_def
    ;

func_def
    : type IDENTIFIER LPAREN param_list RPAREN block {
        $$ = ast_create_node(NODE_FUNC_DEF, yylineno, yycolumn);
        $$->data.func_def.return_type = $1;
        $$->data.func_def.name = $2;
        $$->data.func_def.params = $4->data.block.stmts;
        $$->data.func_def.param_count = $4->data.block.stmt_count;
        free($4);
        $$->data.func_def.body = $6;
    }
    | type IDENTIFIER LPAREN RPAREN block {
        $$ = ast_create_node(NODE_FUNC_DEF, yylineno, yycolumn);
        $$->data.func_def.return_type = $1;
        $$->data.func_def.name = $2;
        $$->data.func_def.params = NULL;
        $$->data.func_def.param_count = 0;
        $$->data.func_def.body = $5;
    }
    | type NEW LPAREN param_list RPAREN block {
        $$ = ast_create_node(NODE_FUNC_DEF, yylineno, yycolumn);
        $$->data.func_def.return_type = $1;
        $$->data.func_def.name = strdup("new");
        $$->data.func_def.params = $4->data.block.stmts;
        $$->data.func_def.param_count = $4->data.block.stmt_count;
        free($4);
        $$->data.func_def.body = $6;
    }
    | type NEW LPAREN RPAREN block {
        $$ = ast_create_node(NODE_FUNC_DEF, yylineno, yycolumn);
        $$->data.func_def.return_type = $1;
        $$->data.func_def.name = strdup("new");
        $$->data.func_def.params = NULL;
        $$->data.func_def.param_count = 0;
        $$->data.func_def.body = $5;
    }
    ;

param_list
    : param {
        $$ = ast_create_node(NODE_BLOCK, yylineno, yycolumn);
        $$->data.block.stmts = malloc(sizeof(AstNode*));
        $$->data.block.stmts[0] = $1;
        $$->data.block.stmt_count = 1;
    }
    | param_list COMMA param {
        AstNode *blk = $1;
        blk->data.block.stmts = realloc(blk->data.block.stmts,
            sizeof(AstNode*) * (blk->data.block.stmt_count + 1));
        blk->data.block.stmts[blk->data.block.stmt_count++] = $3;
        $$ = blk;
    }
    ;

param
    : type IDENTIFIER {
        $$ = ast_create_node(NODE_FUNC_PARAM, yylineno, yycolumn);
        $$->data.func_param.type = $1;
        $$->data.func_param.name = $2;
        $$->data.func_param.is_borrow = 0;
        $$->data.func_param.is_mut = 0;
    }
    | type STAR IDENTIFIER {
        $$ = ast_create_node(NODE_FUNC_PARAM, yylineno, yycolumn);
        $$->data.func_param.type = $1;
        $$->data.func_param.name = $3;
        $$->data.func_param.is_borrow = 0;
        $$->data.func_param.is_mut = 0;
        if ($1->data.type_info.is_pointer) $1->data.type_info.pointer_depth++;
        else { $1->data.type_info.is_pointer = 1; $1->data.type_info.pointer_depth = 1; }
    }
    | BORROW type IDENTIFIER {
        $$ = ast_create_node(NODE_FUNC_PARAM, yylineno, yycolumn);
        $$->data.func_param.type = $2;
        $$->data.func_param.name = $3;
        $$->data.func_param.is_borrow = 1;
        $$->data.func_param.is_mut = 0;
    }
    | BORROW IDENTIFIER {
        $$ = ast_create_node(NODE_FUNC_PARAM, yylineno, yycolumn);
        $$->data.func_param.type = NULL;
        $$->data.func_param.name = $2;
        $$->data.func_param.is_borrow = 1;
        $$->data.func_param.is_mut = 0;
    }
    | MUT type IDENTIFIER {
        $$ = ast_create_node(NODE_FUNC_PARAM, yylineno, yycolumn);
        $$->data.func_param.type = $2;
        $$->data.func_param.name = $3;
        $$->data.func_param.is_borrow = 0;
        $$->data.func_param.is_mut = 1;
    }
    ;

block
    : LBRACE RBRACE {
        $$ = ast_create_node(NODE_BLOCK, yylineno, yycolumn);
        $$->data.block.stmts = NULL;
        $$->data.block.stmt_count = 0;
    }
    | LBRACE stmt_list RBRACE {
        $$ = $2;
    }
    ;

stmt_list
    : stmt {
        $$ = ast_create_node(NODE_BLOCK, yylineno, yycolumn);
        $$->data.block.stmts = malloc(sizeof(AstNode*));
        $$->data.block.stmts[0] = $1;
        $$->data.block.stmt_count = 1;
    }
    | stmt_list stmt {
        AstNode *blk = $1;
        blk->data.block.stmts = realloc(blk->data.block.stmts,
            sizeof(AstNode*) * (blk->data.block.stmt_count + 1));
        blk->data.block.stmts[blk->data.block.stmt_count++] = $2;
        $$ = blk;
    }
    ;

stmt
    : expr opt_semicolon { $$ = $1; }
    | return_stmt { $$ = $1; }
    | if_stmt { $$ = $1; }
    | switch_stmt { $$ = $1; }
    | match_stmt { $$ = $1; }
    | for_stmt { $$ = $1; }
    | using_stmt { $$ = $1; }
    | unsafe_stmt { $$ = $1; }
    | decl_stmt { $$ = $1; }
    ;

opt_semicolon
    : SEMICOLON
    | /* empty */
    ;

decl_stmt
    : type IDENTIFIER ASSIGN expr SEMICOLON {
        $$ = ast_create_node(NODE_BINARY, yylineno, yycolumn);
        $$->data.binary.op_str = strdup("=");
        AstNode *lhs = ast_create_node(NODE_IDENTIFIER, yylineno, yycolumn);
        lhs->data.identifier = $2;
        $$->data.binary.lhs = lhs;
        $$->data.binary.rhs = $4;
    }
    | type IDENTIFIER ASSIGN LBRACE opt_arg_list RBRACE SEMICOLON {
        $$ = ast_create_node(NODE_BINARY, yylineno, yycolumn);
        $$->data.binary.op_str = strdup("=");
        AstNode *lhs = ast_create_node(NODE_IDENTIFIER, yylineno, yycolumn);
        lhs->data.identifier = $2;
        $$->data.binary.lhs = lhs;
        AstNode *init = ast_create_node(NODE_STRUCT_INIT, yylineno, yycolumn);
        if ($5) {
            init->data.struct_init.args = $5->data.block.stmts;
            init->data.struct_init.arg_count = $5->data.block.stmt_count;
            free($5);
        } else {
            init->data.struct_init.args = NULL;
            init->data.struct_init.arg_count = 0;
        }
        $$->data.binary.rhs = init;
    }
    | type STAR IDENTIFIER ASSIGN expr SEMICOLON {
        $$ = ast_create_node(NODE_BINARY, yylineno, yycolumn);
        $$->data.binary.op_str = strdup("=");
        AstNode *lhs = ast_create_node(NODE_IDENTIFIER, yylineno, yycolumn);
        lhs->data.identifier = $3;
        $$->data.binary.lhs = lhs;
        $$->data.binary.rhs = $5;
        if ($1->data.type_info.is_pointer) $1->data.type_info.pointer_depth++;
        else { $1->data.type_info.is_pointer = 1; $1->data.type_info.pointer_depth = 1; }
    }
    | MUT type IDENTIFIER ASSIGN expr SEMICOLON {
        $$ = ast_create_node(NODE_BINARY, yylineno, yycolumn);
        $$->data.binary.op_str = strdup("=");
        AstNode *lhs = ast_create_node(NODE_IDENTIFIER, yylineno, yycolumn);
        lhs->data.identifier = $3;
        $$->data.binary.lhs = lhs;
        $$->data.binary.rhs = $5;
    }
    | MUT type IDENTIFIER ASSIGN LBRACE opt_arg_list RBRACE SEMICOLON {
        $$ = ast_create_node(NODE_BINARY, yylineno, yycolumn);
        $$->data.binary.op_str = strdup("=");
        AstNode *lhs = ast_create_node(NODE_IDENTIFIER, yylineno, yycolumn);
        lhs->data.identifier = $3;
        $$->data.binary.lhs = lhs;
        AstNode *init = ast_create_node(NODE_STRUCT_INIT, yylineno, yycolumn);
        if ($6) {
            init->data.struct_init.args = $6->data.block.stmts;
            init->data.struct_init.arg_count = $6->data.block.stmt_count;
            free($6);
        } else {
            init->data.struct_init.args = NULL;
            init->data.struct_init.arg_count = 0;
        }
        $$->data.binary.rhs = init;
    }
    | BORROW IDENTIFIER ASSIGN expr SEMICOLON {
        $$ = ast_create_node(NODE_BINARY, yylineno, yycolumn);
        $$->data.binary.op_str = strdup("=");
        AstNode *lhs = ast_create_node(NODE_IDENTIFIER, yylineno, yycolumn);
        lhs->data.identifier = $2;
        $$->data.binary.lhs = lhs;
        $$->data.binary.rhs = $4;
    }
    | BORROW MUT IDENTIFIER ASSIGN expr SEMICOLON {
        $$ = ast_create_node(NODE_BINARY, yylineno, yycolumn);
        $$->data.binary.op_str = strdup("=");
        AstNode *lhs = ast_create_node(NODE_IDENTIFIER, yylineno, yycolumn);
        lhs->data.identifier = $3;
        $$->data.binary.lhs = lhs;
        $$->data.binary.rhs = $5;
    }
    ;

return_stmt
    : RETURN SEMICOLON {
        $$ = ast_create_node(NODE_RETURN, yylineno, yycolumn);
        $$->data.unary.operand = NULL;
    }
    | RETURN expr SEMICOLON {
        $$ = ast_create_node(NODE_RETURN, yylineno, yycolumn);
        $$->data.unary.operand = $2;
    }
    ;

if_stmt
    : IF expr block {
        $$ = ast_create_node(NODE_IF, yylineno, yycolumn);
        $$->data.if_stmt.expr = $2;
        $$->data.if_stmt.then_block = $3;
        $$->data.if_stmt.else_block = NULL;
    }
    | IF expr block ELSE if_stmt {
        $$ = ast_create_node(NODE_IF, yylineno, yycolumn);
        $$->data.if_stmt.expr = $2;
        $$->data.if_stmt.then_block = $3;
        $$->data.if_stmt.else_block = $5;
    }
    | IF expr block ELSE block {
        $$ = ast_create_node(NODE_IF, yylineno, yycolumn);
        $$->data.if_stmt.expr = $2;
        $$->data.if_stmt.then_block = $3;
        $$->data.if_stmt.else_block = $5;
    }
    ;

switch_stmt
    : SWITCH LPAREN expr RPAREN LBRACE case_list RBRACE {
        $$ = ast_create_node(NODE_SWITCH, yylineno, yycolumn);
        $$->data.switch_stmt.expr = $3;
        if ($6) {
            $$->data.switch_stmt.cases = $6->data.block.stmts;
            $$->data.switch_stmt.case_count = $6->data.block.stmt_count;
            free($6);
        } else {
            $$->data.switch_stmt.cases = NULL;
            $$->data.switch_stmt.case_count = 0;
        }
    }
    ;

case_list
    : case {
        $$ = ast_create_node(NODE_BLOCK, yylineno, yycolumn);
        $$->data.block.stmts = malloc(sizeof(AstNode*));
        $$->data.block.stmts[0] = $1;
        $$->data.block.stmt_count = 1;
    }
    | case_list case {
        AstNode *blk = $1;
        blk->data.block.stmts = realloc(blk->data.block.stmts,
            sizeof(AstNode*) * (blk->data.block.stmt_count + 1));
        blk->data.block.stmts[blk->data.block.stmt_count++] = $2;
        $$ = blk;
    }
    ;

case
    : CASE expr block {
        $$ = ast_create_node(NODE_CASE, yylineno, yycolumn);
        $$->data.case_branch.value = $2;
        $$->data.case_branch.body = $3;
    }
    | CASE STAR block {
        $$ = ast_create_node(NODE_CASE, yylineno, yycolumn);
        $$->data.case_branch.value = NULL;
        $$->data.case_branch.body = $3;
    }
    ;

match_stmt
    : MATCH LPAREN expr RPAREN LBRACE match_case_list RBRACE {
        $$ = ast_create_node(NODE_MATCH, yylineno, yycolumn);
        $$->data.match_stmt.expr = $3;
        if ($6) {
            $$->data.match_stmt.cases = $6->data.block.stmts;
            $$->data.match_stmt.case_count = $6->data.block.stmt_count;
            free($6);
        } else {
            $$->data.match_stmt.cases = NULL;
            $$->data.match_stmt.case_count = 0;
        }
    }
    ;

match_case_list
    : match_case {
        $$ = ast_create_node(NODE_BLOCK, yylineno, yycolumn);
        $$->data.block.stmts = malloc(sizeof(AstNode*));
        $$->data.block.stmts[0] = $1;
        $$->data.block.stmt_count = 1;
    }
    | match_case_list match_case {
        AstNode *blk = $1;
        blk->data.block.stmts = realloc(blk->data.block.stmts,
            sizeof(AstNode*) * (blk->data.block.stmt_count + 1));
        blk->data.block.stmts[blk->data.block.stmt_count++] = $2;
        $$ = blk;
    }
    ;

match_case
    : CASE IDENTIFIER IN expr block {
        $$ = ast_create_node(NODE_MATCH_CASE, yylineno, yycolumn);
        $$->data.case_branch.value = $4;
        $$->data.case_branch.body = $5;
    }
    | CASE expr block {
        $$ = ast_create_node(NODE_MATCH_CASE, yylineno, yycolumn);
        $$->data.case_branch.value = $2;
        $$->data.case_branch.body = $3;
    }
    | CASE STAR block {
        $$ = ast_create_node(NODE_MATCH_CASE, yylineno, yycolumn);
        $$->data.case_branch.value = NULL;
        $$->data.case_branch.body = $3;
    }
    ;

for_stmt
    : FOR IDENTIFIER IN expr block {
        $$ = ast_create_node(NODE_FOR, yylineno, yycolumn);
        $$->data.for_stmt.var = $2;
        $$->data.for_stmt.range = $4;
        $$->data.for_stmt.body = $5;
    }
    ;

using_stmt
    : USING LPAREN expr RPAREN block {
        $$ = ast_create_node(NODE_USING, yylineno, yycolumn);
        $$->data.using_stmt.resource = $3;
        $$->data.using_stmt.body = $5;
    }
    ;

unsafe_stmt
    : UNSAFE block {
        $$ = ast_create_node(NODE_UNSAFE, yylineno, yycolumn);
        $$->data.unsafe_stmt.body = $2;
    }
    ;

type
    : INT { $$ = ast_create_node(NODE_TYPE, yylineno, yycolumn); $$->data.type_info.base = TYPE_INT; }
    | VOID { $$ = ast_create_node(NODE_TYPE, yylineno, yycolumn); $$->data.type_info.base = TYPE_VOID; }
    | STRING { $$ = ast_create_node(NODE_TYPE, yylineno, yycolumn); $$->data.type_info.base = TYPE_STRING; }
    | LOCK { $$ = ast_create_node(NODE_TYPE, yylineno, yycolumn); $$->data.type_info.base = TYPE_LOCK; }
    | IDENTIFIER { $$ = ast_create_node(NODE_TYPE, yylineno, yycolumn); $$->data.type_info.base = TYPE_CUSTOM; $$->data.type_info.custom_name = $1; }
    ;

arg_list
    : expr {
        $$ = ast_create_node(NODE_BLOCK, yylineno, yycolumn);
        $$->data.block.stmts = malloc(sizeof(AstNode*));
        $$->data.block.stmts[0] = $1;
        $$->data.block.stmt_count = 1;
    }
    | arg_list COMMA expr {
        AstNode *list = $1;
        list->data.block.stmts = realloc(list->data.block.stmts,
            sizeof(AstNode*) * (list->data.block.stmt_count + 1));
        list->data.block.stmts[list->data.block.stmt_count++] = $3;
        $$ = list;
    }
    ;

opt_arg_list
    : /* empty */ { $$ = NULL; }
    | arg_list { $$ = $1; }
    ;

expr
    : postfix_expr { $$ = $1; }
    | expr PLUS expr { $$ = ast_create_node(NODE_BINARY, yylineno, yycolumn); $$->data.binary.op_str = strdup("+"); $$->data.binary.lhs = $1; $$->data.binary.rhs = $3; }
    | expr MINUS expr { $$ = ast_create_node(NODE_BINARY, yylineno, yycolumn); $$->data.binary.op_str = strdup("-"); $$->data.binary.lhs = $1; $$->data.binary.rhs = $3; }
    | expr STAR expr { $$ = ast_create_node(NODE_BINARY, yylineno, yycolumn); $$->data.binary.op_str = strdup("*"); $$->data.binary.lhs = $1; $$->data.binary.rhs = $3; }
    | expr SLASH expr { $$ = ast_create_node(NODE_BINARY, yylineno, yycolumn); $$->data.binary.op_str = strdup("/"); $$->data.binary.lhs = $1; $$->data.binary.rhs = $3; }
    | expr PERCENT expr { $$ = ast_create_node(NODE_BINARY, yylineno, yycolumn); $$->data.binary.op_str = strdup("%"); $$->data.binary.lhs = $1; $$->data.binary.rhs = $3; }
    | expr EQ expr { $$ = ast_create_node(NODE_BINARY, yylineno, yycolumn); $$->data.binary.op_str = strdup("=="); $$->data.binary.lhs = $1; $$->data.binary.rhs = $3; }
    | expr NEQ expr { $$ = ast_create_node(NODE_BINARY, yylineno, yycolumn); $$->data.binary.op_str = strdup("!="); $$->data.binary.lhs = $1; $$->data.binary.rhs = $3; }
    | expr LT expr { $$ = ast_create_node(NODE_BINARY, yylineno, yycolumn); $$->data.binary.op_str = strdup("<"); $$->data.binary.lhs = $1; $$->data.binary.rhs = $3; }
    | expr GT expr { $$ = ast_create_node(NODE_BINARY, yylineno, yycolumn); $$->data.binary.op_str = strdup(">"); $$->data.binary.lhs = $1; $$->data.binary.rhs = $3; }
    | expr LTE expr { $$ = ast_create_node(NODE_BINARY, yylineno, yycolumn); $$->data.binary.op_str = strdup("<="); $$->data.binary.lhs = $1; $$->data.binary.rhs = $3; }
    | expr GTE expr { $$ = ast_create_node(NODE_BINARY, yylineno, yycolumn); $$->data.binary.op_str = strdup(">="); $$->data.binary.lhs = $1; $$->data.binary.rhs = $3; }
    | expr AND expr { $$ = ast_create_node(NODE_BINARY, yylineno, yycolumn); $$->data.binary.op_str = strdup("&&"); $$->data.binary.lhs = $1; $$->data.binary.rhs = $3; }
    | expr OR expr { $$ = ast_create_node(NODE_BINARY, yylineno, yycolumn); $$->data.binary.op_str = strdup("||"); $$->data.binary.lhs = $1; $$->data.binary.rhs = $3; }
    | expr RANGE expr {
        $$ = ast_create_node(NODE_RANGE, yylineno, yycolumn);
        $$->data.range.start = $1;
        $$->data.range.end = $3;
    }
    | expr ASSIGN expr {
        $$ = ast_create_node(NODE_BINARY, yylineno, yycolumn);
        $$->data.binary.op_str = strdup("=");
        $$->data.binary.lhs = $1;
        $$->data.binary.rhs = $3;
    }
    | expr PLUS_ASSIGN expr {
        $$ = ast_create_node(NODE_BINARY, yylineno, yycolumn);
        $$->data.binary.op_str = strdup("+=");
        $$->data.binary.lhs = $1;
        $$->data.binary.rhs = $3;
    }
    | expr MINUS_ASSIGN expr {
        $$ = ast_create_node(NODE_BINARY, yylineno, yycolumn);
        $$->data.binary.op_str = strdup("-=");
        $$->data.binary.lhs = $1;
        $$->data.binary.rhs = $3;
    }
    | expr STAR_ASSIGN expr {
        $$ = ast_create_node(NODE_BINARY, yylineno, yycolumn);
        $$->data.binary.op_str = strdup("*=");
        $$->data.binary.lhs = $1;
        $$->data.binary.rhs = $3;
    }
    | expr SLASH_ASSIGN expr {
        $$ = ast_create_node(NODE_BINARY, yylineno, yycolumn);
        $$->data.binary.op_str = strdup("/=");
        $$->data.binary.lhs = $1;
        $$->data.binary.rhs = $3;
    }
    | MINUS expr %prec UMINUS {
        $$ = ast_create_node(NODE_UNARY, yylineno, yycolumn);
        $$->data.unary.op = strdup("-");
        $$->data.unary.operand = $2;
    }
    | NOT expr %prec NOT {
        $$ = ast_create_node(NODE_UNARY, yylineno, yycolumn);
        $$->data.unary.op = strdup("!");
        $$->data.unary.operand = $2;
    }
    | AMP expr %prec UADDR {
        $$ = ast_create_node(NODE_UNARY, yylineno, yycolumn);
        $$->data.unary.op = strdup("&");
        $$->data.unary.operand = $2;
    }
    | THREAD RUN LPAREN expr RPAREN {
        $$ = ast_create_node(NODE_THREAD_RUN, yylineno, yycolumn);
        $$->data.thread_run.call = $4;
    }
    | THREAD DOT RUN LPAREN expr RPAREN {
        $$ = ast_create_node(NODE_THREAD_RUN, yylineno, yycolumn);
        $$->data.thread_run.call = $5;
    }
    | MEM DOT DROP LPAREN expr RPAREN {
        $$ = ast_create_node(NODE_DROP, yylineno, yycolumn);
        $$->data.drop_expr.expr = $5;
    }
    | MEM DOT SIZEOF LPAREN type RPAREN {
        $$ = ast_create_node(NODE_SIZEOF, yylineno, yycolumn);
        $$->data.sizeof_expr.type = $5;
        $$->data.sizeof_expr.size = NULL;
    }
    | MEM DOT ALLOC LPAREN expr RPAREN {
        $$ = ast_create_node(NODE_CALL, yylineno, yycolumn);
        $$->data.call.name = strdup("mem.alloc");
        $$->data.call.args = malloc(sizeof(AstNode*));
        $$->data.call.args[0] = $5;
        $$->data.call.arg_count = 1;
    }
    | FREE LPAREN expr RPAREN {
        $$ = ast_create_node(NODE_FREE, yylineno, yycolumn);
        $$->data.free_expr.expr = $3;
    }
    ;

postfix_expr
    : primary { $$ = $1; }
    | postfix_expr DOT IDENTIFIER {
        $$ = ast_create_node(NODE_MEMBER_ACCESS, yylineno, yycolumn);
        $$->data.member_access.object = $1;
        $$->data.member_access.member = $3;
    }
    | postfix_expr LPAREN opt_arg_list RPAREN {
        $$ = ast_create_node(NODE_CALL, yylineno, yycolumn);
        if ($1->type == NODE_IDENTIFIER) {
            $$->data.call.name = $1->data.identifier;
            $1->data.identifier = NULL;
            ast_free($1);
        } else {
            $$->data.call.name = NULL;
        }
        if ($3) {
            $$->data.call.args = $3->data.block.stmts;
            $$->data.call.arg_count = $3->data.block.stmt_count;
            free($3);
        } else {
            $$->data.call.args = NULL;
            $$->data.call.arg_count = 0;
        }
    }
    | LBRACE opt_arg_list RBRACE {
        $$ = ast_create_node(NODE_STRUCT_INIT, yylineno, yycolumn);
        if ($2) {
            $$->data.struct_init.args = $2->data.block.stmts;
            $$->data.struct_init.arg_count = $2->data.block.stmt_count;
            free($2);
        } else {
            $$->data.struct_init.args = NULL;
            $$->data.struct_init.arg_count = 0;
        }
    }
    ;

primary
    : INT_LIT {
        $$ = ast_create_node(NODE_INT_LIT, yylineno, yycolumn);
        $$->data.int_value = atol($1);
        free($1);
    }
    | STRING_LIT {
        $$ = ast_create_node(NODE_STRING_LIT, yylineno, yycolumn);
        char *s = $1;
        s++; s[strlen(s)-1] = '\0';
        $$->data.string_value = strdup(s);
        free($1);
    }
    | STRING_INTERP {
        $$ = ast_create_node(NODE_STRING_LIT, yylineno, yycolumn);
        char *s = $1;
        s++; s[strlen(s)-1] = '\0';
        $$->data.string_value = strdup(s);
        free($1);
    }
    | IDENTIFIER {
        $$ = ast_create_node(NODE_IDENTIFIER, yylineno, yycolumn);
        $$->data.identifier = $1;
    }
    | SELF {
        $$ = ast_create_node(NODE_IDENTIFIER, yylineno, yycolumn);
        $$->data.identifier = strdup("self");
    }
    | SUPER {
        $$ = ast_create_node(NODE_IDENTIFIER, yylineno, yycolumn);
        $$->data.identifier = strdup("super");
    }
    | LPAREN expr RPAREN { $$ = $2; }
    | NEW type LPAREN opt_arg_list RPAREN {
        $$ = ast_create_node(NODE_NEW, yylineno, yycolumn);
        $$->data.new_expr.type = $2;
        if ($4) {
            $$->data.new_expr.args = $4->data.block.stmts;
            $$->data.new_expr.arg_count = $4->data.block.stmt_count;
            free($4);
        } else {
            $$->data.new_expr.args = NULL;
            $$->data.new_expr.arg_count = 0;
        }
    }
    | NEW type {
        $$ = ast_create_node(NODE_NEW, yylineno, yycolumn);
        $$->data.new_expr.type = $2;
        $$->data.new_expr.args = NULL;
        $$->data.new_expr.arg_count = 0;
    }
    ;

%%

void yyerror(const char *s) {
    fprintf(stderr, "Parse error at line %d, col %d: %s\n", yylineno, yycolumn, s);
}

AstNode *parse_file(const char *filename) {
    yyin = fopen(filename, "r");
    if (!yyin) {
        fprintf(stderr, "Cannot open file: %s\n", filename);
        return NULL;
    }
    yyparse();
    fclose(yyin);
    return program_root;
}

#ifndef yywrap
int yywrap(void) { return 1; }
#endif
