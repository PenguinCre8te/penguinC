#ifndef AST_H
#define AST_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef enum {
    NODE_PROGRAM,
    NODE_IMPORT,
    NODE_LINK,
    NODE_STRUCT_DEF,
    NODE_CLASS_DEF,
    NODE_FUNC_DEF,
    NODE_FUNC_PARAM,
    NODE_BLOCK,
    NODE_STMT_EXPR,
    NODE_RETURN,
    NODE_IF,
    NODE_SWITCH,
    NODE_CASE,
    NODE_MATCH,
    NODE_MATCH_CASE,
    NODE_FOR,
    NODE_USING,
    NODE_UNSAFE,
    NODE_ASSIGN,
    NODE_COMPOUND_ASSIGN,
    NODE_CALL,
    NODE_MEMBER_ACCESS,
    NODE_NEW,
    NODE_SIZEOF,
    NODE_FREE,
    NODE_DROP,
    NODE_RANGE,
    NODE_UNARY,
    NODE_BINARY,
    NODE_TERNARY,
    NODE_IDENTIFIER,
    NODE_INT_LIT,
    NODE_STRING_LIT,
    NODE_STRING_INTERP,
    NODE_STRUCT_INIT,
    NODE_TYPE,
    NODE_POINTER_TYPE,
    NODE_BORROW_EXPR,
    NODE_THREAD_RUN,
} NodeType;

typedef enum {
    TYPE_INT, TYPE_VOID, TYPE_STRING, TYPE_LOCK,
    TYPE_CUSTOM, TYPE_POINTER, TYPE_BORROW
} BaseType;

typedef enum {
    OP_ADD, OP_SUB, OP_MUL, OP_DIV, OP_MOD,
    OP_EQ, OP_NEQ, OP_LT, OP_GT, OP_LTE, OP_GTE,
    OP_AND, OP_OR, OP_NOT,
    OP_ASSIGN, OP_ADD_ASSIGN, OP_SUB_ASSIGN, OP_MUL_ASSIGN, OP_DIV_ASSIGN,
    OP_BIT_AND, OP_BIT_OR, OP_BIT_NOT, OP_DOT,
    OP_RANGE
} OpType;

typedef struct AstNode AstNode;

typedef struct {
    char *name;
    char *alias; // for struct alias names
} ImportInfo;

typedef struct {
    char *path;
} LinkInfo;

typedef struct {
    char *name;
    AstNode **fields; // list of NODE_FUNC_PARAM
    int field_count;
} StructDef;

typedef struct {
    char *name;
    char *parent;
    AstNode **members;
    int member_count;
} ClassDef;

typedef struct {
    AstNode *type;
    char *name;
    int is_borrow;
    int is_mut;
} FuncParam;

typedef struct {
    AstNode *return_type;
    char *name;
    AstNode **params;
    int param_count;
    AstNode *body;
    int is_method; // 1 if inside class
    char *class_name;
} FuncDef;

typedef struct {
    AstNode **stmts;
    int stmt_count;
} Block;

typedef struct {
    AstNode *expr;
    AstNode *then_block;
    AstNode *else_block; // else if or else block
} IfStmt;

typedef struct {
    AstNode *expr;
    AstNode **cases;
    int case_count;
} SwitchStmt;

typedef struct {
    AstNode *value; // value to match against, or NULL for default
    AstNode *body;
} CaseBranch;

typedef struct {
    AstNode *expr;
    AstNode **cases;
    int case_count;
} MatchStmt;

typedef struct {
    char *var;
    AstNode *range;
    AstNode *body;
} ForStmt;

typedef struct {
    AstNode *resource;
    AstNode *body;
} UsingStmt;

typedef struct {
    AstNode *body;
} UnsafeStmt;

typedef struct {
    char *op_str;
    AstNode *lhs;
    AstNode *rhs;
} BinaryExpr;

typedef struct {
    char *op;
    AstNode *operand;
} UnaryExpr;

typedef struct {
    AstNode *cond;
    AstNode *then_expr;
    AstNode *else_expr;
} TernaryExpr;

typedef struct {
    char *name;
    AstNode **args;
    int arg_count;
} CallExpr;

typedef struct {
    AstNode *object;
    char *member;
} MemberAccess;

typedef struct {
    AstNode *type;
    AstNode **args;
    int arg_count;
} NewExpr;

typedef struct {
    AstNode *type;
    AstNode *size;
} SizeofExpr;

typedef struct {
    AstNode *expr;
} FreeExpr;

typedef struct {
    AstNode *expr;
} DropExpr;

typedef struct {
    AstNode *start;
    AstNode *end;
} RangeExpr;

typedef struct {
    char *value;
} StringInterpPart;

typedef struct {
    AstNode **parts; // StringInterpPart or NODE_IDENTIFIER or NODE_BINARY
    int part_count;
} StringInterp;

typedef struct {
    char *name;
    AstNode **args;
    int arg_count;
} StructInit;

typedef struct {
    BaseType base;
    char *custom_name;
    int is_pointer;
    int pointer_depth;
    int is_borrow;
    int is_mut;
    char *borrow_name;
} TypeInfo;

typedef struct {
    AstNode *expr;
} BorrowExpr;

typedef struct {
    AstNode *call;
} ThreadRun;

struct AstNode {
    NodeType type;
    int line;
    int col;
    union {
        ImportInfo import;
        LinkInfo link;
        StructDef struct_def;
        ClassDef class_def;
        FuncDef func_def;
        FuncParam func_param;
        Block block;
        IfStmt if_stmt;
        SwitchStmt switch_stmt;
        CaseBranch case_branch;
        MatchStmt match_stmt;
        ForStmt for_stmt;
        UsingStmt using_stmt;
        UnsafeStmt unsafe_stmt;
        BinaryExpr binary;
        UnaryExpr unary;
        TernaryExpr ternary;
        CallExpr call;
        MemberAccess member_access;
        NewExpr new_expr;
        SizeofExpr sizeof_expr;
        FreeExpr free_expr;
        DropExpr drop_expr;
        RangeExpr range;
        StringInterp string_interp;
        StructInit struct_init;
        TypeInfo type_info;
        BorrowExpr borrow_expr;
        ThreadRun thread_run;
        char *identifier;
        long int_value;
        char *string_value;
    } data;
};

AstNode *ast_create_node(NodeType type, int line, int col);
void ast_free(AstNode *node);
void ast_print(AstNode *node, int indent);

#endif
