#include "ast.h"
#include <stdio.h>

int yycolumn = 1;
extern AstNode *parse_file(const char *filename);

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <file.pc>\n", argv[0]);
        return 1;
    }

    AstNode *ast = parse_file(argv[1]);
    if (!ast) {
        fprintf(stderr, "Parsing failed.\n");
        return 1;
    }

    printf("AST:\n");
    ast_print(ast, 0);

    ast_free(ast);
    return 0;
}
