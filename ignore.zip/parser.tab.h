/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_YY_PARSER_TAB_H_INCLUDED
# define YY_YY_PARSER_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    IDENTIFIER = 258,              /* IDENTIFIER  */
    INT_LIT = 259,                 /* INT_LIT  */
    STRING_LIT = 260,              /* STRING_LIT  */
    STRING_INTERP = 261,           /* STRING_INTERP  */
    IMPORT = 262,                  /* IMPORT  */
    LINK = 263,                    /* LINK  */
    AS = 264,                      /* AS  */
    STRUCT = 265,                  /* STRUCT  */
    CLASS = 266,                   /* CLASS  */
    EXTENDS = 267,                 /* EXTENDS  */
    VOID = 268,                    /* VOID  */
    INT = 269,                     /* INT  */
    STRING = 270,                  /* STRING  */
    LOCK = 271,                    /* LOCK  */
    MUT = 272,                     /* MUT  */
    BORROW = 273,                  /* BORROW  */
    NEW = 274,                     /* NEW  */
    SELF = 275,                    /* SELF  */
    SUPER = 276,                   /* SUPER  */
    USING = 277,                   /* USING  */
    SWITCH = 278,                  /* SWITCH  */
    CASE = 279,                    /* CASE  */
    MATCH = 280,                   /* MATCH  */
    UNSAFE = 281,                  /* UNSAFE  */
    FOR = 282,                     /* FOR  */
    IN = 283,                      /* IN  */
    RETURN = 284,                  /* RETURN  */
    IF = 285,                      /* IF  */
    ELSE = 286,                    /* ELSE  */
    THREAD = 287,                  /* THREAD  */
    RUN = 288,                     /* RUN  */
    MEM = 289,                     /* MEM  */
    ALLOC = 290,                   /* ALLOC  */
    SIZEOF = 291,                  /* SIZEOF  */
    DROP = 292,                    /* DROP  */
    FREE = 293,                    /* FREE  */
    PLUS = 294,                    /* PLUS  */
    MINUS = 295,                   /* MINUS  */
    STAR = 296,                    /* STAR  */
    SLASH = 297,                   /* SLASH  */
    PERCENT = 298,                 /* PERCENT  */
    PLUS_ASSIGN = 299,             /* PLUS_ASSIGN  */
    MINUS_ASSIGN = 300,            /* MINUS_ASSIGN  */
    STAR_ASSIGN = 301,             /* STAR_ASSIGN  */
    SLASH_ASSIGN = 302,            /* SLASH_ASSIGN  */
    EQ = 303,                      /* EQ  */
    NEQ = 304,                     /* NEQ  */
    LT = 305,                      /* LT  */
    GT = 306,                      /* GT  */
    LTE = 307,                     /* LTE  */
    GTE = 308,                     /* GTE  */
    ASSIGN = 309,                  /* ASSIGN  */
    AND = 310,                     /* AND  */
    OR = 311,                      /* OR  */
    NOT = 312,                     /* NOT  */
    AMP = 313,                     /* AMP  */
    PIPE = 314,                    /* PIPE  */
    TILDE = 315,                   /* TILDE  */
    RANGE = 316,                   /* RANGE  */
    ARROW = 317,                   /* ARROW  */
    LPAREN = 318,                  /* LPAREN  */
    RPAREN = 319,                  /* RPAREN  */
    LBRACE = 320,                  /* LBRACE  */
    RBRACE = 321,                  /* RBRACE  */
    LBRACKET = 322,                /* LBRACKET  */
    RBRACKET = 323,                /* RBRACKET  */
    SEMICOLON = 324,               /* SEMICOLON  */
    COLON = 325,                   /* COLON  */
    DOT = 326,                     /* DOT  */
    COMMA = 327,                   /* COMMA  */
    UMINUS = 328,                  /* UMINUS  */
    UADDR = 329,                   /* UADDR  */
    USTAR = 330                    /* USTAR  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 16 "parser.y"

    char *string_val;
    long int_val;
    struct AstNode *node;

#line 145 "parser.tab.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;


int yyparse (void);


#endif /* !YY_YY_PARSER_TAB_H_INCLUDED  */
